import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, Building, Users, BookOpen, Target, GraduationCap, X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { normalizeCode } from "@/lib/normalization";

export const AdminPanel = () => {
  const { toast } = useToast();
  const [newFaculty, setNewFaculty] = useState({ name: "", description: "" });
  const [newCareer, setNewCareer] = useState({ name: "", description: "", facultyId: "" });
  const [newSubject, setNewSubject] = useState({ name: "", code: "", careerId: "", contributionToCareer: "", contents: [""], generalCompetencies: [] as string[] });
  const [newGeneralCompetency, setNewGeneralCompetency] = useState({ name: "", description: "" });
  const [newSpecificCompetency, setNewSpecificCompetency] = useState({ name: "", description: "", careerId: "" });
  const [learningOutcomes, setLearningOutcomes] = useState<string[]>([""]);
  
  
  const [faculties, setFaculties] = useState<any[]>([]);
  const [careers, setCareers] = useState<any[]>([]);
  const [generalCompetencies, setGeneralCompetencies] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    fetchFaculties();
    fetchCareers();
    fetchGeneralCompetencies();
  }, []);

  const fetchFaculties = async () => {
    try {
      const { data, error } = await supabase
        .from('faculties')
        .select('*')
        .order('name');
      
      if (error) throw error;
      setFaculties(data || []);
    } catch (error) {
      console.error('Error fetching faculties:', error);
    }
  };

  const fetchCareers = async () => {
    try {
      const { data, error } = await supabase
        .from('careers')
        .select('*')
        .order('name');
      
      if (error) throw error;
      setCareers(data || []);
    } catch (error) {
      console.error('Error fetching careers:', error);
    }
  };

  const fetchGeneralCompetencies = async () => {
    try {
      const { data, error } = await supabase
        .from('general_competencies')
        .select('*')
        .order('name');
      
      if (error) throw error;
      setGeneralCompetencies(data || []);
    } catch (error) {
      console.error('Error fetching general competencies:', error);
    }
  };

  const handleSubmitFaculty = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    try {
      const { data, error } = await supabase
        .from('faculties')
        .insert([{
          name: newFaculty.name,
          description: newFaculty.description
        }])
        .select();

      if (error) throw error;

      toast({
        title: "Facultad creada",
        description: `La facultad "${newFaculty.name}" ha sido creada exitosamente.`,
      });
      
      setNewFaculty({ name: "", description: "" });
      await fetchFaculties();
    } catch (error) {
      console.error('Error creating faculty:', error);
      toast({
        title: "Error",
        description: "No se pudo crear la facultad. Inténtalo de nuevo.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmitCareer = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    try {
      const { data, error } = await supabase
        .from('careers')
        .insert([{
          name: newCareer.name,
          description: newCareer.description,
          faculty_id: newCareer.facultyId || null
        }])
        .select();

      if (error) throw error;

      toast({
        title: "Carrera creada",
        description: `La carrera "${newCareer.name}" ha sido creada exitosamente.`,
      });
      
      setNewCareer({ name: "", description: "", facultyId: "" });
      await fetchCareers();
    } catch (error) {
      console.error('Error creating career:', error);
      toast({
        title: "Error",
        description: "No se pudo crear la carrera. Inténtalo de nuevo.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmitSubject = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    try {
      const validContents = newSubject.contents.filter(content => content.trim() !== "");
        const { data: subjectData, error: subjectError } = await supabase
          .from('subjects')
          .insert([{
            name: newSubject.name,
            code: newSubject.code,
            career_id: newSubject.careerId || null,
            contribution_to_career: newSubject.contributionToCareer,
            contents: validContents
          }])
          .select()
          .single();

      if (subjectError) throw subjectError;

      // Create learning outcomes for the subject
      const validLearningOutcomes = learningOutcomes.filter(outcome => outcome.trim() !== "");
      if (validLearningOutcomes.length > 0) {
        const { error: learningError } = await supabase
          .from('learning_outcomes')
          .insert(
            validLearningOutcomes.map(outcome => ({
              subject_id: subjectData.id,
              description: outcome.trim()
            }))
          );

        if (learningError) throw learningError;
      }

      // Associate selected general competencies with the subject
      if (newSubject.generalCompetencies.length > 0) {
        const { error: competenciesError } = await supabase
          .from('subject_general_competencies')
          .insert(
            newSubject.generalCompetencies.map(competencyId => ({
              subject_id: subjectData.id,
              general_competency_id: competencyId
            }))
          );

        if (competenciesError) throw competenciesError;
      }

      toast({
        title: "Asignatura creada",
        description: `La asignatura "${newSubject.name}" ha sido creada exitosamente con ${validLearningOutcomes.length} resultados de aprendizaje y ${newSubject.generalCompetencies.length} competencias generales asociadas.`,
      });
      
      setNewSubject({ name: "", code: "", careerId: "", contributionToCareer: "", contents: [""], generalCompetencies: [] });
      setLearningOutcomes([""]);
    } catch (error) {
      console.error('Error creating subject:', error);
      toast({
        title: "Error",
        description: "No se pudo crear la asignatura. Inténtalo de nuevo.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmitGeneralCompetency = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    try {
      const { data, error } = await supabase
        .from('general_competencies')
        .insert([{
          name: newGeneralCompetency.name,
          description: newGeneralCompetency.description,
          faculty_id: null // Las competencias generales están disponibles para todas las facultades
        }])
        .select();

      if (error) throw error;

      toast({
        title: "Competencia general creada",
        description: "La competencia general ha sido creada exitosamente.",
      });
      
      setNewGeneralCompetency({ name: "", description: "" });
    } catch (error) {
      console.error('Error creating general competency:', error);
      toast({
        title: "Error",
        description: "No se pudo crear la competencia general. Inténtalo de nuevo.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmitSpecificCompetency = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    try {
      // Crear la competencia específica
      const { data: competencyData, error: competencyError } = await supabase
        .from('specific_competencies')
        .insert([{
          name: newSpecificCompetency.name,
          description: newSpecificCompetency.description
        }])
        .select()
        .single();

      if (competencyError) throw competencyError;

      // Asociar la competencia específica con la carrera seleccionada
      const { error: associationError } = await supabase
        .from('career_specific_competencies')
        .insert([{
          career_id: newSpecificCompetency.careerId,
          specific_competency_id: competencyData.id
        }]);

      if (associationError) throw associationError;

      toast({
        title: "Competencia específica creada",
        description: "La competencia específica ha sido creada y asociada a la carrera exitosamente.",
      });
      
      setNewSpecificCompetency({ name: "", description: "", careerId: "" });
    } catch (error) {
      console.error('Error creating specific competency:', error);
      toast({
        title: "Error",
        description: "No se pudo crear la competencia específica. Inténtalo de nuevo.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };


  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-semibold mb-2">Panel de Administración</h2>
        <p className="text-muted-foreground">
          Gestiona la estructura académica y las competencias institucionales
        </p>
      </div>

      <Tabs defaultValue="faculties" className="space-y-4">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="faculties" className="flex items-center gap-2">
            <Building className="h-4 w-4" />
            Facultades
          </TabsTrigger>
          <TabsTrigger value="careers" className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            Carreras
          </TabsTrigger>
          <TabsTrigger value="general-comp" className="flex items-center gap-2">
            <Target className="h-4 w-4" />
            CG
          </TabsTrigger>
          <TabsTrigger value="specific-comp" className="flex items-center gap-2">
            <Target className="h-4 w-4" />
            CE
          </TabsTrigger>
          <TabsTrigger value="subjects" className="flex items-center gap-2">
            <BookOpen className="h-4 w-4" />
            Asignaturas
          </TabsTrigger>
        </TabsList>

        <TabsContent value="faculties" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Plus className="h-5 w-5" />
                Nueva Facultad
              </CardTitle>
              <CardDescription>
                Crea una nueva facultad en la universidad
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmitFaculty} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="faculty-name">Nombre de la Facultad</Label>
                  <Input
                    id="faculty-name"
                    placeholder="Ej: Facultad de Ingeniería"
                    value={newFaculty.name}
                    onChange={(e) => setNewFaculty({...newFaculty, name: e.target.value})}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="faculty-description">Descripción</Label>
                  <Textarea
                    id="faculty-description"
                    placeholder="Descripción de la facultad..."
                    value={newFaculty.description}
                    onChange={(e) => setNewFaculty({...newFaculty, description: e.target.value})}
                  />
                </div>
                <Button type="submit" disabled={isLoading}>
                  {isLoading ? "Creando..." : "Crear Facultad"}
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="careers" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Plus className="h-5 w-5" />
                Nueva Carrera
              </CardTitle>
              <CardDescription>
                Crea una nueva carrera universitaria
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmitCareer} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="career-faculty">Facultad</Label>
                  <Select value={newCareer.facultyId} onValueChange={(value) => setNewCareer({...newCareer, facultyId: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecciona una facultad" />
                    </SelectTrigger>
                    <SelectContent>
                      {faculties.map((faculty) => (
                        <SelectItem key={faculty.id} value={faculty.id}>
                          {faculty.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="career-name">Nombre de la Carrera</Label>
                  <Input
                    id="career-name"
                    placeholder="Ej: Ingeniería de Sistemas"
                    value={newCareer.name}
                    onChange={(e) => setNewCareer({...newCareer, name: e.target.value})}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="career-description">Descripción</Label>
                  <Textarea
                    id="career-description"
                    placeholder="Descripción de la carrera..."
                    value={newCareer.description}
                    onChange={(e) => setNewCareer({...newCareer, description: e.target.value})}
                  />
                </div>
                <Button type="submit" disabled={isLoading}>
                  {isLoading ? "Creando..." : "Crear Carrera"}
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="subjects" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Plus className="h-5 w-5" />
                Nueva Asignatura
              </CardTitle>
              <CardDescription>
                Crea una nueva asignatura para una carrera
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmitSubject} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="subject-career">Carrera</Label>
                  <Select value={newSubject.careerId} onValueChange={(value) => setNewSubject({...newSubject, careerId: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecciona una carrera" />
                    </SelectTrigger>
                    <SelectContent>
                      {careers.map((career) => (
                        <SelectItem key={career.id} value={career.id}>
                          {career.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="subject-name">Nombre de la Asignatura</Label>
                    <Input
                      id="subject-name"
                      placeholder="Ej: Matemáticas I"
                      value={newSubject.name}
                      onChange={(e) => setNewSubject({...newSubject, name: e.target.value})}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="subject-code">Código</Label>
                    <Input
                      id="subject-code"
                      placeholder="Ej: MAT101"
                      value={newSubject.code}
                      onChange={(e) => setNewSubject({...newSubject, code: normalizeCode(e.target.value)})}
                      required
                    />
                  </div>
                </div>
                
                {/* Contribution to Career */}
                <div className="space-y-2">
                  <Label htmlFor="subject-contribution">Contribución a la carrera</Label>
                  <Textarea
                    id="subject-contribution"
                    placeholder="Describe cómo esta asignatura contribuye al perfil profesional..."
                    value={newSubject.contributionToCareer}
                    onChange={(e) => setNewSubject({...newSubject, contributionToCareer: e.target.value})}
                    rows={3}
                  />
                </div>
                
                {/* Contents Section */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label>Contenidos de la Asignatura</Label>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => setNewSubject({...newSubject, contents: [...newSubject.contents, ""]})}
                    >
                      <Plus className="h-4 w-4 mr-2" />
                      Agregar Contenido
                    </Button>
                  </div>
                  {newSubject.contents.map((content, index) => (
                    <div key={index} className="flex items-end gap-2">
                      <div className="flex-1 space-y-2">
                        <Label htmlFor={`content-${index}`}>Contenido {index + 1}</Label>
                        <Textarea
                          id={`content-${index}`}
                          placeholder="Descripción del contenido..."
                          value={content}
                          onChange={(e) => {
                            const updated = [...newSubject.contents];
                            updated[index] = e.target.value;
                            setNewSubject({...newSubject, contents: updated});
                          }}
                          rows={2}
                        />
                      </div>
                      {newSubject.contents.length > 1 && (
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            const updated = newSubject.contents.filter((_, i) => i !== index);
                            setNewSubject({...newSubject, contents: updated});
                          }}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  ))}
                </div>

                {/* Learning Outcomes Section */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label>Resultados de Aprendizaje (RDA)</Label>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => setLearningOutcomes([...learningOutcomes, ""])}
                    >
                      <Plus className="h-4 w-4 mr-2" />
                      Agregar RDA
                    </Button>
                  </div>
                  {learningOutcomes.map((outcome, index) => (
                    <div key={index} className="flex items-end gap-2">
                      <div className="flex-1 space-y-2">
                        <Label htmlFor={`outcome-${index}`}>RDA {index + 1}</Label>
                        <Textarea
                          id={`outcome-${index}`}
                          placeholder="Descripción del resultado de aprendizaje..."
                          value={outcome}
                          onChange={(e) => {
                            const updated = [...learningOutcomes];
                            updated[index] = e.target.value;
                            setLearningOutcomes(updated);
                          }}
                          rows={2}
                        />
                      </div>
                      {learningOutcomes.length > 1 && (
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            const updated = learningOutcomes.filter((_, i) => i !== index);
                            setLearningOutcomes(updated);
                          }}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  ))}
                </div>

                {/* General Competencies Selection */}
                <div className="space-y-4">
                  <Label>Competencias Generales</Label>
                  <p className="text-sm text-muted-foreground">Selecciona las competencias generales que estarán asociadas a esta asignatura</p>
                  <div className="grid grid-cols-1 gap-2 max-h-60 overflow-y-auto border rounded-md p-3">
                    {generalCompetencies.map((competency) => (
                      <div key={competency.id} className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          id={`comp-${competency.id}`}
                          checked={newSubject.generalCompetencies.includes(competency.id)}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setNewSubject({
                                ...newSubject,
                                generalCompetencies: [...newSubject.generalCompetencies, competency.id]
                              });
                            } else {
                              setNewSubject({
                                ...newSubject,
                                generalCompetencies: newSubject.generalCompetencies.filter(id => id !== competency.id)
                              });
                            }
                          }}
                        />
                        <Label htmlFor={`comp-${competency.id}`} className="text-sm font-normal">
                          <span className="font-medium">{competency.name || competency.code}</span>
                          {competency.description && (
                            <span className="block text-xs text-muted-foreground">{competency.description}</span>
                          )}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>

                <Button type="submit" disabled={isLoading}>
                  {isLoading ? "Creando..." : "Crear Asignatura"}
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>


        <TabsContent value="general-comp" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Plus className="h-5 w-5" />
                Nueva Competencia General
              </CardTitle>
               <CardDescription>
                 Define competencias generales disponibles para todas las facultades y carreras
               </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmitGeneralCompetency} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="gen-comp-name">Nombre de la Competencia</Label>
                  <Input
                    id="gen-comp-name"
                    placeholder="Ej: Comunicación efectiva"
                    value={newGeneralCompetency.name}
                    onChange={(e) => setNewGeneralCompetency({...newGeneralCompetency, name: e.target.value})}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="gen-comp-description">Descripción de la Competencia</Label>
                  <Textarea
                    id="gen-comp-description"
                    placeholder="Describe la competencia general..."
                    value={newGeneralCompetency.description}
                    onChange={(e) => setNewGeneralCompetency({...newGeneralCompetency, description: e.target.value})}
                    required
                  />
                </div>
                <Button type="submit" disabled={isLoading}>
                  {isLoading ? "Creando..." : "Crear Competencia General"}
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="specific-comp" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Plus className="h-5 w-5" />
                Nueva Competencia Específica
              </CardTitle>
              <CardDescription>
                Define competencias específicas a nivel de carrera
              </CardDescription>
            </CardHeader>
             <CardContent>
               <form onSubmit={handleSubmitSpecificCompetency} className="space-y-4">
                 <div className="space-y-2">
                   <Label htmlFor="spec-comp-career">Carrera</Label>
                   <Select value={newSpecificCompetency.careerId} onValueChange={(value) => setNewSpecificCompetency({...newSpecificCompetency, careerId: value})}>
                     <SelectTrigger>
                       <SelectValue placeholder="Selecciona una carrera" />
                     </SelectTrigger>
                     <SelectContent>
                       {careers.map((career) => (
                         <SelectItem key={career.id} value={career.id}>
                           {career.name}
                         </SelectItem>
                       ))}
                     </SelectContent>
                   </Select>
                 </div>
                 <div className="space-y-2">
                   <Label htmlFor="spec-comp-name">Nombre de la Competencia</Label>
                   <Input
                     id="spec-comp-name"
                     placeholder="Ej: Análisis de sistemas"
                     value={newSpecificCompetency.name}
                     onChange={(e) => setNewSpecificCompetency({...newSpecificCompetency, name: e.target.value})}
                     required
                   />
                 </div>
                 <div className="space-y-2">
                   <Label htmlFor="spec-comp-description">Descripción de la Competencia</Label>
                   <Textarea
                     id="spec-comp-description"
                     placeholder="Describe la competencia específica..."
                     value={newSpecificCompetency.description}
                     onChange={(e) => setNewSpecificCompetency({...newSpecificCompetency, description: e.target.value})}
                     required
                   />
                 </div>
                 <Button type="submit" disabled={isLoading || !newSpecificCompetency.careerId}>
                   {isLoading ? "Creando..." : "Crear Competencia Específica"}
                 </Button>
               </form>
             </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};