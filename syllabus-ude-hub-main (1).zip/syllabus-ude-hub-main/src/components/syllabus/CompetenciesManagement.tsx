import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Plus, Edit2, Trash2, Save, X, Search, ArrowUpDown, ArrowUp, ArrowDown } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useSpecificCompetenciesPaginated } from "@/hooks/useSpecificCompetenciesPaginated";
import { Skeleton } from "@/components/ui/skeleton";

interface Faculty {
  id: string;
  name: string;
}

interface Career {
  id: string;
  name: string;
  faculty_id: string;
}

interface GeneralCompetency {
  id: string;
  code?: string;
  name?: string;
  description: string;
  faculty_id?: string;
  faculties?: { name: string };
}

interface SpecificCompetency {
  id: string;
  code?: string;
  name?: string;
  description: string;
}

export const CompetenciesManagement = () => {
  const { toast } = useToast();
  const [faculties, setFaculties] = useState<Faculty[]>([]);
  const [careers, setCareers] = useState<Career[]>([]);
  const [generalCompetencies, setGeneralCompetencies] = useState<GeneralCompetency[]>([]);
  const [specificCompetencies, setSpecificCompetencies] = useState<SpecificCompetency[]>([]);
  
  // Form states
  const [showGeneralForm, setShowGeneralForm] = useState(false);
  const [showSpecificForm, setShowSpecificForm] = useState(false);
  const [editingGeneral, setEditingGeneral] = useState<GeneralCompetency | null>(null);
  const [editingSpecific, setEditingSpecific] = useState<SpecificCompetency | null>(null);
  
  // Form data
  const [generalForm, setGeneralForm] = useState({ name: "", description: "", faculty_id: "" });
  const [specificForm, setSpecificForm] = useState({ name: "", description: "", career_ids: [] as string[] });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [facultiesRes, careersRes, generalRes, specificRes] = await Promise.all([
        supabase.from("faculties").select("*").order("name", { ascending: true }),
        supabase.from("careers").select("*").order("name", { ascending: true }),
        supabase.from("general_competencies").select("*, faculties(name)").order("description", { ascending: true }),
        supabase.from("specific_competencies").select("*").order("description", { ascending: true })
      ]);

      if (facultiesRes.error) throw facultiesRes.error;
      if (careersRes.error) throw careersRes.error;
      if (generalRes.error) throw generalRes.error;
      if (specificRes.error) throw specificRes.error;

      setFaculties(facultiesRes.data || []);
      setCareers(careersRes.data || []);
      setGeneralCompetencies(generalRes.data || []);
      setSpecificCompetencies(specificRes.data || []);
    } catch (error) {
      console.error("Error fetching data:", error);
      toast({
        title: "Error",
        description: "No se pudieron cargar los datos",
        variant: "destructive",
      });
    }
  };

  const handleSaveGeneral = async () => {
    if (!generalForm.name || !generalForm.description) {
      toast({
        title: "Error",
        description: "Nombre y descripción son requeridos",
        variant: "destructive",
      });
      return;
    }

    try {
      if (editingGeneral) {
        const { error } = await supabase
          .from("general_competencies")
          .update({
            name: generalForm.name,
            description: generalForm.description,
            faculty_id: generalForm.faculty_id,
          })
          .eq("id", editingGeneral.id);

        if (error) throw error;
        toast({ title: "Éxito", description: "Competencia general actualizada correctamente" });
      } else {
        const { error } = await supabase
          .from("general_competencies")
          .insert([{
            name: generalForm.name,
            description: generalForm.description,
            faculty_id: generalForm.faculty_id,
          }]);

        if (error) throw error;
        toast({ title: "Éxito", description: "Competencia general creada correctamente" });
      }

      setGeneralForm({ name: "", description: "", faculty_id: "" });
      setShowGeneralForm(false);
      setEditingGeneral(null);
      fetchData();
    } catch (error) {
      console.error("Error saving general competency:", error);
      toast({
        title: "Error",
        description: "No se pudo guardar la competencia general",
        variant: "destructive",
      });
    }
  };

  const handleSaveSpecific = async () => {
    if (!specificForm.name || !specificForm.description || specificForm.career_ids.length === 0) {
      toast({
        title: "Error",
        description: "Todos los campos son requeridos",
        variant: "destructive",
      });
      return;
    }

    try {
      if (editingSpecific) {
        // Update the competency name and description
        const { error: updateError } = await supabase
          .from("specific_competencies")
          .update({
            name: specificForm.name,
            description: specificForm.description,
          })
          .eq("id", editingSpecific.id);

        if (updateError) throw updateError;

        // Delete existing career relationships
        const { error: deleteError } = await supabase
          .from("career_specific_competencies")
          .delete()
          .eq("specific_competency_id", editingSpecific.id);

        if (deleteError) throw deleteError;

        // Insert new career relationships
        const { error: insertError } = await supabase
          .from("career_specific_competencies")
          .insert(specificForm.career_ids.map(career_id => ({
            career_id,
            specific_competency_id: editingSpecific.id
          })));

        if (insertError) throw insertError;

        toast({ title: "Éxito", description: "Competencia específica actualizada correctamente" });
      } else {
        // Create new competency
        const { data: competencyData, error: competencyError } = await supabase
          .from("specific_competencies")
          .insert([{
            name: specificForm.name,
            description: specificForm.description,
          }])
          .select()
          .single();

        if (competencyError) throw competencyError;

        // Insert career relationships
        const { error: relationshipError } = await supabase
          .from("career_specific_competencies")
          .insert(specificForm.career_ids.map(career_id => ({
            career_id,
            specific_competency_id: competencyData.id
          })));

        if (relationshipError) throw relationshipError;

        toast({ title: "Éxito", description: "Competencia específica creada correctamente" });
      }

      setSpecificForm({ name: "", description: "", career_ids: [] });
      setShowSpecificForm(false);
      setEditingSpecific(null);
      fetchData();
    } catch (error) {
      console.error("Error saving specific competency:", error);
      toast({
        title: "Error",
        description: "No se pudo guardar la competencia específica",
        variant: "destructive",
      });
    }
  };

  const handleDeleteGeneral = async (id: string) => {
    if (!confirm("¿Está seguro de que desea eliminar esta competencia general?")) return;

    try {
      const { error } = await supabase
        .from("general_competencies")
        .delete()
        .eq("id", id);

      if (error) throw error;
      toast({ title: "Éxito", description: "Competencia general eliminada correctamente" });
      fetchData();
    } catch (error) {
      console.error("Error deleting general competency:", error);
      toast({
        title: "Error",
        description: "No se pudo eliminar la competencia general",
        variant: "destructive",
      });
    }
  };

  const handleDeleteSpecific = async (id: string) => {
    if (!confirm("¿Está seguro de que desea eliminar esta competencia específica?")) return;

    try {
      const { error } = await supabase
        .from("specific_competencies")
        .delete()
        .eq("id", id);

      if (error) throw error;
      toast({ title: "Éxito", description: "Competencia específica eliminada correctamente" });
      fetchData();
    } catch (error) {
      console.error("Error deleting specific competency:", error);
      toast({
        title: "Error",
        description: "No se pudo eliminar la competencia específica",
        variant: "destructive",
      });
    }
  };

  const startEditGeneral = (competency: GeneralCompetency) => {
    setEditingGeneral(competency);
    setGeneralForm({
      name: competency.name || "",
      description: competency.description,
      faculty_id: competency.faculty_id,
    });
    setShowGeneralForm(true);
  };

  const startEditSpecific = async (competency: SpecificCompetency) => {
    setEditingSpecific(competency);
    
    // Get associated careers for this competency
    try {
      const { data: careerData, error } = await supabase
        .from("career_specific_competencies")
        .select("career_id")
        .eq("specific_competency_id", competency.id);
      
      if (error) throw error;
      
      setSpecificForm({
        name: competency.name || "",
        description: competency.description,
        career_ids: careerData?.map(item => item.career_id) || [],
      });
    } catch (error) {
      console.error("Error fetching career relationships:", error);
      setSpecificForm({
        name: competency.name || "",
        description: competency.description,
        career_ids: [],
      });
    }
    
    setShowSpecificForm(true);
  };

  const cancelEdit = () => {
    setShowGeneralForm(false);
    setShowSpecificForm(false);
    setEditingGeneral(null);
    setEditingSpecific(null);
    setGeneralForm({ name: "", description: "", faculty_id: "" });
    setSpecificForm({ name: "", description: "", career_ids: [] });
};

// Component for the specific competencies section with pagination
interface SpecificCompetenciesSectionProps {
  onSpecificCompetencyUpdated: () => void;
  careers: Career[];
  faculties: Faculty[];
}

const SpecificCompetenciesSection = ({ onSpecificCompetencyUpdated, careers, faculties }: SpecificCompetenciesSectionProps) => {
  const { toast } = useToast();
  const [showSpecificForm, setShowSpecificForm] = useState(false);
  const [editingSpecific, setEditingSpecific] = useState<SpecificCompetency | null>(null);
  const [specificForm, setSpecificForm] = useState({ name: "", description: "", career_ids: [] as string[] });

  const {
    competencies,
    pagination,
    isLoading,
    searchTerm,
    setSearchTerm,
    careerFilter,
    setCareerFilter,
    facultyFilter,
    setFacultyFilter,
    sortBy,
    setSortBy,
    sortOrder,
    setSortOrder,
    goToPage,
    refreshCompetencies,
    deleteCompetency
  } = useSpecificCompetenciesPaginated();

  const handleSort = (field: string) => {
    if (sortBy === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(field);
      setSortOrder('asc');
    }
  };

  const generatePaginationItems = () => {
    const items = [];
    const totalPages = pagination.totalPages;
    const currentPage = pagination.page;
    
    if (totalPages <= 7) {
      for (let i = 1; i <= totalPages; i++) {
        items.push(i);
      }
    } else {
      items.push(1);
      
      if (currentPage <= 4) {
        items.push(2, 3, 4, 5, '...', totalPages);
      } else if (currentPage >= totalPages - 3) {
        items.push('...', totalPages - 4, totalPages - 3, totalPages - 2, totalPages - 1, totalPages);
      } else {
        items.push('...', currentPage - 1, currentPage, currentPage + 1, '...', totalPages);
      }
    }
    
    return items;
  };

  const handleSaveSpecific = async () => {
    if (!specificForm.name || !specificForm.description || specificForm.career_ids.length === 0) {
      toast({
        title: "Error",
        description: "Todos los campos son requeridos",
        variant: "destructive",
      });
      return;
    }

    try {
      if (editingSpecific) {
        // Update the competency name and description
        const { error: updateError } = await supabase
          .from("specific_competencies")
          .update({
            name: specificForm.name,
            description: specificForm.description,
          })
          .eq("id", editingSpecific.id);

        if (updateError) throw updateError;

        // Delete existing career relationships
        const { error: deleteError } = await supabase
          .from("career_specific_competencies")
          .delete()
          .eq("specific_competency_id", editingSpecific.id);

        if (deleteError) throw deleteError;

        // Insert new career relationships
        const { error: insertError } = await supabase
          .from("career_specific_competencies")
          .insert(specificForm.career_ids.map(career_id => ({
            career_id,
            specific_competency_id: editingSpecific.id
          })));

        if (insertError) throw insertError;

        toast({ title: "Éxito", description: "Competencia específica actualizada correctamente" });
      } else {
        // Create new competency
        const { data: competencyData, error: competencyError } = await supabase
          .from("specific_competencies")
          .insert([{
            name: specificForm.name,
            description: specificForm.description,
          }])
          .select()
          .single();

        if (competencyError) throw competencyError;

        // Insert career relationships
        const { error: relationshipError } = await supabase
          .from("career_specific_competencies")
          .insert(specificForm.career_ids.map(career_id => ({
            career_id,
            specific_competency_id: competencyData.id
          })));

        if (relationshipError) throw relationshipError;

        toast({ title: "Éxito", description: "Competencia específica creada correctamente" });
      }

      setSpecificForm({ name: "", description: "", career_ids: [] });
      setShowSpecificForm(false);
      setEditingSpecific(null);
      await refreshCompetencies();
      onSpecificCompetencyUpdated();
    } catch (error) {
      console.error("Error saving specific competency:", error);
      toast({
        title: "Error",
        description: "No se pudo guardar la competencia específica",
        variant: "destructive",
      });
    }
  };

  const startEditSpecific = async (competency: SpecificCompetency) => {
    setEditingSpecific(competency);
    
    // Get associated careers for this competency
    try {
      const { data: careerData, error } = await supabase
        .from("career_specific_competencies")
        .select("career_id")
        .eq("specific_competency_id", competency.id);
      
      if (error) throw error;
      
      setSpecificForm({
        name: competency.name || "",
        description: competency.description,
        career_ids: careerData?.map(item => item.career_id) || [],
      });
    } catch (error) {
      console.error("Error fetching career relationships:", error);
      setSpecificForm({
        name: competency.name || "",
        description: competency.description,
        career_ids: [],
      });
    }
    
    setShowSpecificForm(true);
  };

  const cancelEdit = () => {
    setShowSpecificForm(false);
    setEditingSpecific(null);
    setSpecificForm({ name: "", description: "", career_ids: [] });
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>Competencias Específicas</CardTitle>
          <CardDescription>
            Gestión de competencias específicas por carrera ({pagination.total} total)
          </CardDescription>
        </div>
        <Button onClick={() => setShowSpecificForm(true)} disabled={showSpecificForm}>
          <Plus className="h-4 w-4 mr-2" />
          Nueva Competencia Específica
        </Button>
      </CardHeader>
      <CardContent className="space-y-4">
        {showSpecificForm && (
          <Card className="border-primary/20">
            <CardHeader>
              <CardTitle className="text-lg">
                {editingSpecific ? "Editar Competencia Específica" : "Nueva Competencia Específica"}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Nombre</label>
                <Input
                  value={specificForm.name}
                  onChange={(e) => setSpecificForm(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="Nombre de la competencia específica"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Descripción</label>
                <Textarea
                  value={specificForm.description}
                  onChange={(e) => setSpecificForm(prev => ({ ...prev, description: e.target.value }))}
                  placeholder="Descripción de la competencia específica"
                  rows={3}
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Carreras Asociadas</label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 max-h-48 overflow-y-auto border rounded-md p-2">
                  {careers.map((career) => (
                    <label key={career.id} className="flex items-center space-x-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={specificForm.career_ids.includes(career.id)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setSpecificForm(prev => ({
                              ...prev,
                              career_ids: [...prev.career_ids, career.id]
                            }));
                          } else {
                            setSpecificForm(prev => ({
                              ...prev,
                              career_ids: prev.career_ids.filter(id => id !== career.id)
                            }));
                          }
                        }}
                        className="rounded"
                      />
                      <span className="text-sm">{career.name}</span>
                    </label>
                  ))}
                </div>
              </div>
              <div className="flex gap-2">
                <Button onClick={handleSaveSpecific}>
                  <Save className="h-4 w-4 mr-2" />
                  Guardar
                </Button>
                <Button variant="outline" onClick={cancelEdit}>
                  <X className="h-4 w-4 mr-2" />
                  Cancelar
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Search and Filter Card */}
        <Card>
          <CardContent className="pt-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                <Input
                  placeholder="Buscar competencias..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={careerFilter} onValueChange={setCareerFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Filtrar por carrera" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas las carreras</SelectItem>
                  {careers.map((career) => (
                    <SelectItem key={career.id} value={career.id}>
                      {career.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={facultyFilter} onValueChange={setFacultyFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Filtrar por facultad" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas las facultades</SelectItem>
                  {faculties.map((faculty) => (
                    <SelectItem key={faculty.id} value={faculty.id}>
                      {faculty.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <div className="flex gap-2">
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => handleSort('description')}
                  className="flex items-center gap-1"
                >
                  Descripción
                  {sortBy === 'description' ? (
                    sortOrder === 'asc' ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />
                  ) : (
                    <ArrowUpDown className="h-3 w-3" />
                  )}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Competencies List */}
        {isLoading ? (
          <div className="space-y-3">
            {Array.from({ length: 5 }).map((_, i) => (
              <Card key={i}>
                <CardContent className="pt-4">
                  <div className="flex justify-between items-start gap-4">
                    <div className="flex-1 space-y-2">
                      <div className="flex gap-2">
                        <Skeleton className="h-5 w-16" />
                        <Skeleton className="h-5 w-20" />
                      </div>
                      <Skeleton className="h-4 w-32" />
                      <Skeleton className="h-4 w-full" />
                    </div>
                    <div className="flex gap-2">
                      <Skeleton className="h-8 w-8" />
                      <Skeleton className="h-8 w-8" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : competencies.length > 0 ? (
          <div className="space-y-3">
            {competencies.map((competency) => (
              <Card key={competency.id}>
                <CardContent className="pt-4">
                  <div className="flex justify-between items-start gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2 flex-wrap">
                        {competency.code && (
                          <Badge variant="outline">{competency.code}</Badge>
                        )}
                        {competency.career_names && competency.career_names.length > 0 ? (
                          competency.career_names.map((careerName, index) => (
                            <Badge key={index} variant="secondary">
                              {careerName}
                            </Badge>
                          ))
                        ) : (
                          <Badge variant="secondary">Transversal</Badge>
                        )}
                        <Badge variant="outline">
                          {competency.career_count || 0} carrera(s)
                        </Badge>
                      </div>
                      {competency.name && (
                        <h4 className="font-medium text-sm mb-1">{competency.name}</h4>
                      )}
                      <p className="text-sm text-muted-foreground">{competency.description}</p>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => startEditSpecific(competency)}
                      >
                        <Edit2 className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => deleteCompetency(competency.id, competency.name || competency.description)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="pt-8 pb-8">
              <p className="text-center text-muted-foreground">
                {searchTerm || careerFilter !== "all" || facultyFilter !== "all"
                  ? "No se encontraron competencias específicas con los filtros aplicados"
                  : "No hay competencias específicas registradas"}
              </p>
            </CardContent>
          </Card>
        )}

        {/* Pagination */}
        {pagination.totalPages > 1 && (
          <div className="flex items-center justify-between">
            <p className="text-sm text-muted-foreground">
              Mostrando {((pagination.page - 1) * pagination.pageSize) + 1} a{" "}
              {Math.min(pagination.page * pagination.pageSize, pagination.total)} de {pagination.total} competencias
            </p>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => goToPage(pagination.page - 1)}
                disabled={pagination.page === 1}
              >
                Anterior
              </Button>
              {generatePaginationItems().map((item, index) => (
                <Button
                  key={index}
                  variant={item === pagination.page ? "default" : "outline"}
                  size="sm"
                  onClick={() => typeof item === 'number' && goToPage(item)}
                  disabled={item === '...'}
                  className="min-w-[40px]"
                >
                  {item}
                </Button>
              ))}
              <Button
                variant="outline"
                size="sm"
                onClick={() => goToPage(pagination.page + 1)}
                disabled={pagination.page >= pagination.totalPages}
              >
                Siguiente
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-semibold">Gestión de Competencias</h2>
        <p className="text-muted-foreground">
          Define competencias generales y específicas para las facultades y carreras
        </p>
      </div>

      <Tabs defaultValue="general" className="space-y-6">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="general">Competencias Generales</TabsTrigger>
          <TabsTrigger value="specific">Competencias Específicas</TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="space-y-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Competencias Generales</CardTitle>
                <CardDescription>Competencias a nivel de facultad</CardDescription>
              </div>
              <Button onClick={() => setShowGeneralForm(true)} disabled={showGeneralForm}>
                <Plus className="h-4 w-4 mr-2" />
                Nueva Competencia General
              </Button>
            </CardHeader>
            <CardContent className="space-y-4">
              {showGeneralForm && (
                <Card className="border-primary/20">
                  <CardHeader>
                    <CardTitle className="text-lg">
                      {editingGeneral ? "Editar Competencia General" : "Nueva Competencia General"}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Facultad</label>
                      <Select
                        value={generalForm.faculty_id}
                        onValueChange={(value) => setGeneralForm(prev => ({ ...prev, faculty_id: value }))}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Seleccionar facultad" />
                        </SelectTrigger>
                        <SelectContent>
                          {faculties.map((faculty) => (
                            <SelectItem key={faculty.id} value={faculty.id}>
                              {faculty.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Nombre</label>
                      <Input
                        value={generalForm.name}
                        onChange={(e) => setGeneralForm(prev => ({ ...prev, name: e.target.value }))}
                        placeholder="Nombre de la competencia general"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Descripción</label>
                      <Textarea
                        value={generalForm.description}
                        onChange={(e) => setGeneralForm(prev => ({ ...prev, description: e.target.value }))}
                        placeholder="Descripción de la competencia general"
                        rows={3}
                      />
                    </div>
                    <div className="flex gap-2">
                      <Button onClick={handleSaveGeneral}>
                        <Save className="h-4 w-4 mr-2" />
                        Guardar
                      </Button>
                      <Button variant="outline" onClick={cancelEdit}>
                        <X className="h-4 w-4 mr-2" />
                        Cancelar
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}

              <div className="space-y-3">
                {generalCompetencies.map((competency) => (
                  <Card key={competency.id}>
                    <CardContent className="pt-4">
                      <div className="flex justify-between items-start gap-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <Badge variant="secondary">
                              {competency.faculties?.name || "Sin facultad"}
                            </Badge>
                            {competency.code && (
                              <Badge variant="outline">
                                {competency.code}
                              </Badge>
                            )}
                          </div>
                          {competency.name && (
                            <h4 className="font-medium text-sm mb-1">{competency.name}</h4>
                          )}
                          <p className="text-sm text-muted-foreground">{competency.description}</p>
                        </div>
                        <div className="flex gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => startEditGeneral(competency)}
                          >
                            <Edit2 className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleDeleteGeneral(competency.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
                {generalCompetencies.length === 0 && (
                  <p className="text-center text-muted-foreground py-8">
                    No hay competencias generales registradas
                  </p>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="specific" className="space-y-6">
          <SpecificCompetenciesSection 
            onSpecificCompetencyUpdated={fetchData}
            careers={careers}
            faculties={faculties}
          />
        </TabsContent>
      </Tabs>
    </div>
  );
};