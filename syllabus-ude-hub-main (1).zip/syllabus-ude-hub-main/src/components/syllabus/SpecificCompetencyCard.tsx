import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Edit2, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

interface SpecificCompetency {
  id: string;
  code?: string;
  name?: string;
  description: string;
}

interface Career {
  id: string;
  name: string;
}

interface SpecificCompetencyCardProps {
  competency: SpecificCompetency;
  onEdit: (competency: SpecificCompetency) => void;
  onDelete: (id: string) => void;
}

export const SpecificCompetencyCard = ({ competency, onEdit, onDelete }: SpecificCompetencyCardProps) => {
  const [associatedCareers, setAssociatedCareers] = useState<Career[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAssociatedCareers();
  }, [competency.id]);

  const fetchAssociatedCareers = async () => {
    try {
      setLoading(true);
      // First get career IDs
      const { data: careerIds, error: careerIdsError } = await supabase
        .from("career_specific_competencies")
        .select("career_id")
        .eq("specific_competency_id", competency.id);

      if (careerIdsError) throw careerIdsError;

      if (!careerIds || careerIds.length === 0) {
        setAssociatedCareers([]);
        return;
      }

      // Then get career details
      const { data: careersData, error: careersError } = await supabase
        .from("careers")
        .select("id, name")
        .in("id", careerIds.map(item => item.career_id));

      if (careersError) throw careersError;

      setAssociatedCareers(careersData || []);
    } catch (error) {
      console.error("Error fetching associated careers:", error);
      setAssociatedCareers([]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card>
      <CardContent className="pt-4">
        <div className="flex justify-between items-start gap-4">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2 flex-wrap">
              {competency.code && (
                <Badge variant="outline">
                  {competency.code}
                </Badge>
              )}
              {loading ? (
                <Badge variant="secondary">Cargando...</Badge>
              ) : associatedCareers.length > 0 ? (
                associatedCareers.map((career) => (
                  <Badge key={career.id} variant="secondary">
                    {career.name}
                  </Badge>
                ))
              ) : (
                <Badge variant="secondary">Transversal</Badge>
              )}
            </div>
            {competency.name && (
              <h4 className="font-medium text-sm mb-1">{competency.name}</h4>
            )}
            <p className="text-sm text-muted-foreground">{competency.description}</p>
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => onEdit(competency)}
            >
              <Edit2 className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => onDelete(competency.id)}
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};