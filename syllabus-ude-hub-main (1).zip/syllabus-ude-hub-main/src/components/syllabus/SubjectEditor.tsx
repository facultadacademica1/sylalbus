import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, X, ArrowLeft, Save } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Badge } from "@/components/ui/badge";
import { normalizeCode } from "@/lib/normalization";

interface SubjectEditorProps {
  subjectId: string;
  onBack: () => void;
}

export const SubjectEditor = ({ subjectId, onBack }: SubjectEditorProps) => {
  const { toast } = useToast();
  
  const [subject, setSubject] = useState<any>(null);
  const [learningOutcomes, setLearningOutcomes] = useState<any[]>([]);
  const [subjectGeneralCompetencies, setSubjectGeneralCompetencies] = useState<any[]>([]);
  const [availableGeneralCompetencies, setAvailableGeneralCompetencies] = useState<any[]>([]);
  const [newOutcome, setNewOutcome] = useState("");
  const [selectedCompetencyId, setSelectedCompetencyId] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [editingOutcome, setEditingOutcome] = useState<any>(null);
  const [hasChanges, setHasChanges] = useState(false);

  useEffect(() => {
    fetchSubject();
    fetchLearningOutcomes();
    fetchSubjectGeneralCompetencies();
    fetchAvailableGeneralCompetencies();
  }, [subjectId]);

  const fetchSubject = async () => {
    try {
      const { data, error } = await supabase
        .from('subjects')
        .select('*, careers(name)')
        .eq('id', subjectId)
        .single();
      
      if (error) throw error;
      setSubject(data);
    } catch (error) {
      console.error('Error fetching subject:', error);
    }
  };

  const fetchLearningOutcomes = async () => {
    try {
      const { data, error } = await supabase
        .from('learning_outcomes')
        .select('*')
        .eq('subject_id', subjectId)
        .order('created_at');
      
      if (error) throw error;
      setLearningOutcomes(data || []);
    } catch (error) {
      console.error('Error fetching learning outcomes:', error);
    }
  };

  const fetchSubjectGeneralCompetencies = async () => {
    try {
      const { data, error } = await supabase
        .from('subject_general_competencies')
        .select(`
          *,
          general_competencies (*)
        `)
        .eq('subject_id', subjectId);
      
      if (error) throw error;
      setSubjectGeneralCompetencies(data || []);
    } catch (error) {
      console.error('Error fetching subject general competencies:', error);
    }
  };

  const fetchAvailableGeneralCompetencies = async () => {
    try {
      const { data, error } = await supabase
        .from('general_competencies')
        .select('*')
        .order('name');
      
      if (error) throw error;
      setAvailableGeneralCompetencies(data || []);
    } catch (error) {
      console.error('Error fetching available general competencies:', error);
    }
  };

  const handleSaveSubject = async () => {
    if (!subject) return;
    
    setIsLoading(true);
    try {
      const { error } = await supabase
        .from('subjects')
        .update({
          name: subject.name,
          code: subject.code,
          contribution_to_career: subject.contribution_to_career,
          contents: subject.contents
        })
        .eq('id', subjectId);

      if (error) throw error;

      toast({
        title: "Asignatura actualizada",
        description: "Los cambios han sido guardados exitosamente.",
      });
      
      setHasChanges(false);
    } catch (error) {
      console.error('Error updating subject:', error);
      toast({
        title: "Error",
        description: "No se pudo actualizar la asignatura.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddOutcome = async () => {
    if (!newOutcome.trim()) return;
    
    setIsLoading(true);
    try {
      const { error } = await supabase
        .from('learning_outcomes')
        .insert([{
          description: newOutcome.trim(),
          subject_id: subjectId
        }]);

      if (error) throw error;

      toast({
        title: "Resultado agregado",
        description: "El resultado de aprendizaje ha sido añadido.",
      });
      
      setNewOutcome("");
      await fetchLearningOutcomes();
    } catch (error) {
      console.error('Error adding learning outcome:', error);
      toast({
        title: "Error",
        description: "No se pudo agregar el resultado de aprendizaje.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleUpdateOutcome = async (outcomeId: string, description: string) => {
    setIsLoading(true);
    try {
      const { error } = await supabase
        .from('learning_outcomes')
        .update({ description })
        .eq('id', outcomeId);

      if (error) throw error;

      toast({
        title: "Resultado actualizado",
        description: "El resultado de aprendizaje ha sido actualizado.",
      });
      
      await fetchLearningOutcomes();
      setEditingOutcome(null);
    } catch (error) {
      console.error('Error updating learning outcome:', error);
      toast({
        title: "Error",
        description: "No se pudo actualizar el resultado de aprendizaje.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteOutcome = async (outcomeId: string) => {
    if (!confirm("¿Estás seguro de eliminar este resultado de aprendizaje?")) return;
    
    setIsLoading(true);
    try {
      const { error } = await supabase
        .from('learning_outcomes')
        .delete()
        .eq('id', outcomeId);

      if (error) throw error;

      toast({
        title: "Resultado eliminado",
        description: "El resultado de aprendizaje ha sido eliminado.",
      });
      
      await fetchLearningOutcomes();
    } catch (error) {
      console.error('Error deleting learning outcome:', error);
      toast({
        title: "Error",
        description: "No se pudo eliminar el resultado de aprendizaje.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddGeneralCompetency = async () => {
    if (!selectedCompetencyId) return;
    
    setIsLoading(true);
    try {
      const { error } = await supabase
        .from('subject_general_competencies')
        .insert([{
          subject_id: subjectId,
          general_competency_id: selectedCompetencyId
        }]);

      if (error) throw error;

      toast({
        title: "Competencia agregada",
        description: "La competencia general ha sido asociada a la asignatura.",
      });
      
      setSelectedCompetencyId("");
      await fetchSubjectGeneralCompetencies();
    } catch (error) {
      console.error('Error adding general competency:', error);
      toast({
        title: "Error",
        description: "No se pudo agregar la competencia general.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleRemoveGeneralCompetency = async (relationId: string) => {
    if (!confirm("¿Estás seguro de remover esta competencia de la asignatura?")) return;
    
    setIsLoading(true);
    try {
      const { error } = await supabase
        .from('subject_general_competencies')
        .delete()
        .eq('id', relationId);

      if (error) throw error;

      toast({
        title: "Competencia removida",
        description: "La competencia general ha sido removida de la asignatura.",
      });
      
      await fetchSubjectGeneralCompetencies();
    } catch (error) {
      console.error('Error removing general competency:', error);
      toast({
        title: "Error",
        description: "No se pudo remover la competencia general.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubjectChange = (field: string, value: any) => {
    setSubject(prev => ({
      ...prev,
      [field]: value
    }));
    setHasChanges(true);
  };

  if (!subject) {
    return <div>Cargando...</div>;
  }

  const availableCompetencies = availableGeneralCompetencies.filter(
    comp => !subjectGeneralCompetencies.some(
      sgc => sgc.general_competency_id === comp.id
    )
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="ghost" onClick={onBack}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Volver a la lista
          </Button>
          <div>
            <h2 className="text-2xl font-semibold">Editar Asignatura</h2>
            <p className="text-muted-foreground">{subject.name}</p>
          </div>
        </div>
        <Button 
          onClick={handleSaveSubject} 
          disabled={isLoading || !hasChanges}
          className="bg-primary hover:bg-primary/90"
        >
          <Save className="h-4 w-4 mr-2" />
          Guardar Cambios
        </Button>
      </div>

      {/* Información básica de la asignatura */}
      <Card>
        <CardHeader>
          <CardTitle>Información Básica</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Nombre de la Asignatura</Label>
              <Input
                value={subject.name || ''}
                onChange={(e) => handleSubjectChange('name', e.target.value)}
                placeholder="Nombre de la asignatura"
              />
            </div>
            <div className="space-y-2">
              <Label>Código</Label>
              <Input
                value={subject.code || ''}
                onChange={(e) => handleSubjectChange('code', normalizeCode(e.target.value))}
                placeholder="Código de la asignatura"
              />
            </div>
          </div>
          
          <div className="space-y-2">
            <Label>Contribución a la Carrera</Label>
            <Textarea
              value={subject.contribution_to_career || ''}
              onChange={(e) => handleSubjectChange('contribution_to_career', e.target.value)}
              placeholder="Describe cómo contribuye esta asignatura a la carrera..."
              rows={3}
            />
          </div>
          
          <div className="space-y-2">
            <Label>Contenidos</Label>
            <Textarea
              placeholder="Ingrese los contenidos separados por comas..."
              value={subject.contents ? subject.contents.join(', ') : ''}
              onChange={(e) => handleSubjectChange('contents', 
                e.target.value.split(',').map((item: string) => item.trim()).filter((item: string) => item.length > 0)
              )}
              rows={4}
            />
            {subject.contents && subject.contents.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-2">
                {subject.contents.map((content: string, index: number) => (
                  <Badge key={index} variant="secondary">
                    {content}
                  </Badge>
                ))}
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Competencias Generales */}
      <Card>
        <CardHeader>
          <CardTitle>Competencias Generales</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Agregar nueva competencia */}
          <div className="flex gap-2">
            <Select value={selectedCompetencyId} onValueChange={setSelectedCompetencyId}>
              <SelectTrigger className="flex-1">
                <SelectValue placeholder="Seleccionar competencia general..." />
              </SelectTrigger>
              <SelectContent>
                {availableCompetencies.map((competency) => (
                  <SelectItem key={competency.id} value={competency.id}>
                    {competency.name} {competency.code && `(${competency.code})`}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button 
              onClick={handleAddGeneralCompetency}
              disabled={!selectedCompetencyId || isLoading}
            >
              <Plus className="h-4 w-4 mr-2" />
              Agregar
            </Button>
          </div>

          {/* Lista de competencias asociadas */}
          <div className="space-y-2">
            {subjectGeneralCompetencies.length === 0 ? (
              <p className="text-muted-foreground text-sm">
                No hay competencias generales asociadas.
              </p>
            ) : (
              subjectGeneralCompetencies.map((relation) => (
                <div key={relation.id} className="flex items-start justify-between p-3 border rounded-lg">
                  <div className="flex-1">
                    <p className="font-medium">{relation.general_competencies?.name}</p>
                    <p className="text-sm text-muted-foreground">{relation.general_competencies?.description}</p>
                    {relation.general_competencies?.code && (
                      <Badge variant="outline" className="mt-1">
                        {relation.general_competencies.code}
                      </Badge>
                    )}
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleRemoveGeneralCompetency(relation.id)}
                    disabled={isLoading}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      {/* Resultados de Aprendizaje */}
      <Card>
        <CardHeader>
          <CardTitle>Resultados de Aprendizaje</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Agregar nuevo resultado */}
          <div className="flex gap-2">
            <Textarea
              placeholder="Describe el nuevo resultado de aprendizaje..."
              value={newOutcome}
              onChange={(e) => setNewOutcome(e.target.value)}
              className="flex-1"
              rows={2}
            />
            <Button 
              onClick={handleAddOutcome} 
              disabled={isLoading || !newOutcome.trim()}
            >
              <Plus className="h-4 w-4 mr-2" />
              Agregar
            </Button>
          </div>

          {/* Lista de resultados existentes */}
          <div className="space-y-2">
            {learningOutcomes.length === 0 ? (
              <p className="text-muted-foreground text-sm">
                No hay resultados de aprendizaje definidos.
              </p>
            ) : (
              learningOutcomes.map((outcome, index) => (
                <div key={outcome.id} className="p-3 border rounded-lg">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <Badge variant="outline">RDA {index + 1}</Badge>
                      {outcome.code && <Badge variant="secondary">{outcome.code}</Badge>}
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setEditingOutcome(outcome)}
                        disabled={isLoading}
                      >
                        Editar
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleDeleteOutcome(outcome.id)}
                        disabled={isLoading}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  
                  {editingOutcome?.id === outcome.id ? (
                    <div className="space-y-2">
                      <Textarea
                        value={editingOutcome.description}
                        onChange={(e) => setEditingOutcome({...editingOutcome, description: e.target.value})}
                        rows={3}
                      />
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          onClick={() => handleUpdateOutcome(outcome.id, editingOutcome.description)}
                          disabled={isLoading}
                        >
                          Guardar
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setEditingOutcome(null)}
                        >
                          Cancelar
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <p className="text-sm text-muted-foreground">{outcome.description}</p>
                  )}
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};