import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Edit, X, BookOpen, Search, Target, Filter, ArrowUpDown } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { 
  Pagination, 
  PaginationContent, 
  PaginationItem, 
  PaginationLink, 
  PaginationNext, 
  PaginationPrevious,
  PaginationEllipsis 
} from "@/components/ui/pagination";
import { SubjectEditor } from "./SubjectEditor";
import { SubjectTableSkeleton } from "./SubjectTableSkeleton";
import { useSubjectsPaginated } from "@/hooks/useSubjectsPaginated";
import { supabase } from "@/integrations/supabase/client";

interface SubjectLearningOutcomesProps {
  onClose?: () => void;
}

export const SubjectLearningOutcomes = ({ onClose }: SubjectLearningOutcomesProps) => {
  const [editingSubjectId, setEditingSubjectId] = useState<string | null>(null);
  const [careers, setCareers] = useState<any[]>([]);
  const [faculties, setFaculties] = useState<any[]>([]);

  const {
    subjects,
    pagination,
    isLoading,
    searchTerm,
    careerFilter,
    facultyFilter,
    sortBy,
    sortOrder,
    setSearchTerm,
    setCareerFilter,
    setFacultyFilter,
    setSortBy,
    setSortOrder,
    goToPage,
    refreshSubjects,
    deleteSubject
  } = useSubjectsPaginated(25);

  // Fetch filter options
  useEffect(() => {
    const fetchFilterOptions = async () => {
      try {
        const [careersResponse, facultiesResponse] = await Promise.all([
          supabase.from('careers').select('id, name').order('name'),
          supabase.from('faculties').select('id, name').order('name')
        ]);

        if (careersResponse.data) setCareers(careersResponse.data);
        if (facultiesResponse.data) setFaculties(facultiesResponse.data);
      } catch (error) {
        console.error('Error fetching filter options:', error);
      }
    };

    fetchFilterOptions();
  }, []);

  const handleSort = (field: string) => {
    if (sortBy === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(field);
      setSortOrder('asc');
    }
  };

  const generatePaginationItems = () => {
    const items = [];
    const { page, totalPages } = pagination;
    
    // Always show first page
    items.push(1);
    
    if (totalPages <= 7) {
      // Show all pages if total is small
      for (let i = 2; i <= totalPages; i++) {
        items.push(i);
      }
    } else {
      // Show smart pagination
      if (page <= 4) {
        for (let i = 2; i <= 5; i++) items.push(i);
        items.push('ellipsis');
        items.push(totalPages);
      } else if (page >= totalPages - 3) {
        items.push('ellipsis');
        for (let i = totalPages - 4; i <= totalPages; i++) items.push(i);
      } else {
        items.push('ellipsis');
        for (let i = page - 1; i <= page + 1; i++) items.push(i);
        items.push('ellipsis');
        items.push(totalPages);
      }
    }
    
    return items;
  };

  if (editingSubjectId) {
    return (
      <SubjectEditor
        subjectId={editingSubjectId}
        onBack={() => {
          setEditingSubjectId(null);
          refreshSubjects(); // Refresh the list when coming back
        }}
      />
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-semibold">Gestión de Asignaturas</h2>
          <p className="text-muted-foreground">
            Administra las asignaturas con paginación y filtros avanzados ({pagination.total} asignaturas)
          </p>
        </div>
        {onClose && (
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        )}
      </div>

      {/* Search and Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            Filtros y Búsqueda
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar asignaturas..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            
            <Select value={careerFilter} onValueChange={setCareerFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Filtrar por carrera" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas las carreras</SelectItem>
                {careers.map((career) => (
                  <SelectItem key={career.id} value={career.id}>
                    {career.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger>
                <SelectValue placeholder="Ordenar por" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="name">Nombre</SelectItem>
                <SelectItem value="code">Código</SelectItem>
                <SelectItem value="career">Carrera</SelectItem>
              </SelectContent>
            </Select>

            <Button
              variant="outline"
              onClick={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')}
              className="flex items-center gap-2"
            >
              <ArrowUpDown className="h-4 w-4" />
              {sortOrder === 'asc' ? 'Ascendente' : 'Descendente'}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Results */}
      {isLoading ? (
        <SubjectTableSkeleton />
      ) : (
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <BookOpen className="h-5 w-5" />
                Asignaturas (Página {pagination.page} de {pagination.totalPages})
              </CardTitle>
              <div className="text-sm text-muted-foreground">
                Mostrando {subjects.length} de {pagination.total} asignaturas
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {subjects.length === 0 ? (
              <div className="text-center py-12">
                <BookOpen className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium mb-2">No se encontraron asignaturas</h3>
                <p className="text-muted-foreground">
                  {searchTerm.trim() || careerFilter 
                    ? "Intenta ajustar los filtros de búsqueda." 
                    : "No hay asignaturas disponibles en el sistema."}
                </p>
              </div>
            ) : (
              <>
                <div className="space-y-4">
                  {subjects.map((subject) => (
                    <div
                      key={subject.id}
                      className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors group"
                    >
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h3 className="font-medium text-lg group-hover:text-primary transition-colors">
                            {subject.name}
                          </h3>
                          <Badge variant="secondary">{subject.code}</Badge>
                          {subject.careers?.name && (
                            <Badge variant="outline">{subject.careers.name}</Badge>
                          )}
                        </div>
                        
                        <div className="flex items-center gap-6 text-sm text-muted-foreground mb-2">
                          <div className="flex items-center gap-2">
                            <Target className="h-4 w-4" />
                            <span>{subject.learning_outcomes_count} Resultados</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <BookOpen className="h-4 w-4" />
                            <span>{subject.general_competencies_count} Competencias</span>
                          </div>
                        </div>

                        {subject.contribution_to_career && (
                          <p className="text-sm text-muted-foreground line-clamp-2 mb-2">
                            <strong>Contribución:</strong> {subject.contribution_to_career}
                          </p>
                        )}

                        {subject.contents && subject.contents.length > 0 && (
                          <div className="flex flex-wrap gap-1">
                            {subject.contents.slice(0, 4).map((content: string, index: number) => (
                              <Badge key={index} variant="outline" className="text-xs">
                                {content}
                              </Badge>
                            ))}
                            {subject.contents.length > 4 && (
                              <Badge variant="outline" className="text-xs">
                                +{subject.contents.length - 4} más
                              </Badge>
                            )}
                          </div>
                        )}
                      </div>

                      <div className="flex gap-2 ml-4">
                        <Button
                          variant="default"
                          size="sm"
                          onClick={() => setEditingSubjectId(subject.id)}
                          disabled={isLoading}
                        >
                          <Edit className="h-4 w-4 mr-2" />
                          Editar
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => deleteSubject(subject.id, subject.name)}
                          disabled={isLoading}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Pagination */}
                {pagination.totalPages > 1 && (
                  <div className="mt-6 flex justify-center">
                    <Pagination>
                      <PaginationContent>
                        <PaginationItem>
                          <PaginationPrevious 
                            onClick={() => goToPage(Math.max(1, pagination.page - 1))}
                            className={pagination.page === 1 ? "pointer-events-none opacity-50" : "cursor-pointer"}
                          />
                        </PaginationItem>
                        
                        {generatePaginationItems().map((item, index) => (
                          <PaginationItem key={index}>
                            {item === 'ellipsis' ? (
                              <PaginationEllipsis />
                            ) : (
                              <PaginationLink
                                onClick={() => goToPage(item as number)}
                                isActive={item === pagination.page}
                                className="cursor-pointer"
                              >
                                {item}
                              </PaginationLink>
                            )}
                          </PaginationItem>
                        ))}
                        
                        <PaginationItem>
                          <PaginationNext 
                            onClick={() => goToPage(Math.min(pagination.totalPages, pagination.page + 1))}
                            className={pagination.page === pagination.totalPages ? "pointer-events-none opacity-50" : "cursor-pointer"}
                          />
                        </PaginationItem>
                      </PaginationContent>
                    </Pagination>
                  </div>
                )}
              </>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
};