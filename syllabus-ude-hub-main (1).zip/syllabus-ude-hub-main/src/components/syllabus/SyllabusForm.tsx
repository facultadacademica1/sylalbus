import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { X, Plus } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

interface SyllabusFormProps {
  onClose: () => void;
  editingSyllabus?: any;
  viewOnly?: boolean;
}

export const SyllabusForm = ({ onClose, editingSyllabus, viewOnly = false }: SyllabusFormProps) => {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    subjectId: "",
    contactHours: "",
    practicalExperimentalHours: "",
    autonomousLearningHours: "",
    modalidad: "presencial",
  });

  const [selectedSubject, setSelectedSubject] = useState<any>(null);

  const [selectedLearningOutcomes, setSelectedLearningOutcomes] = useState<string[]>([]);
  const [availableLearningOutcomes, setAvailableLearningOutcomes] = useState<any[]>([]);
  const [bibliography, setBibliography] = useState<Array<{
    title: string;
    author: string;
    year: string;
    publisher: string;
    type: "basica" | "complementaria";
  }>>([
    { title: "", author: "", year: "", publisher: "", type: "basica" }
  ]);
  
  const [subjects, setSubjects] = useState<any[]>([]);
  const [generalCompetencies, setGeneralCompetencies] = useState<any[]>([]);
  const [specificCompetencies, setSpecificCompetencies] = useState<any[]>([]);
  const [selectedGeneralCompetencies, setSelectedGeneralCompetencies] = useState<{[key: string]: string}>({});
  const [selectedSpecificCompetencies, setSelectedSpecificCompetencies] = useState<{[key: string]: string}>({});
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    fetchSubjects();
    if (editingSyllabus) {
      loadSyllabusData();
    }
  }, [editingSyllabus]);

  useEffect(() => {
    if (formData.subjectId) {
      fetchSelectedSubject();
      fetchLearningOutcomes();
      fetchSpecificCompetenciesForSubject();
      fetchCompetencies();
      // Limpiar las competencias seleccionadas al cambiar la asignatura
      setSelectedSpecificCompetencies({});
      setSelectedGeneralCompetencies({});
    } else {
      setSelectedSubject(null);
      setSpecificCompetencies([]);
      setGeneralCompetencies([]);
      setSelectedSpecificCompetencies({});
      setSelectedGeneralCompetencies({});
    }
  }, [formData.subjectId]);

  const fetchSubjects = async () => {
    try {
      const { data, error } = await supabase
        .from('subjects')
        .select('*, careers(name)')
        .order('name');
      
      if (error) throw error;
      setSubjects(data || []);
    } catch (error) {
      console.error('Error fetching subjects:', error);
    }
  };

  const fetchSelectedSubject = async () => {
    if (!formData.subjectId) {
      setSelectedSubject(null);
      return;
    }
    
    try {
      const { data, error } = await supabase
        .from('subjects')
        .select('*, careers(name)')
        .eq('id', formData.subjectId)
        .single();
      
      if (error) throw error;
      setSelectedSubject(data);
    } catch (error) {
      console.error('Error fetching selected subject:', error);
      setSelectedSubject(null);
    }
  };

  const fetchLearningOutcomes = async () => {
    if (!formData.subjectId) return;
    
    try {
      const { data, error } = await supabase
        .from('learning_outcomes')
        .select('*')
        .eq('subject_id', formData.subjectId)
        .order('created_at');
      
      if (error) throw error;
      setAvailableLearningOutcomes(data || []);
      // Pre-select all available learning outcomes
      setSelectedLearningOutcomes(data?.map(lo => lo.id) || []);
    } catch (error) {
      console.error('Error fetching learning outcomes:', error);
    }
  };

  const fetchCompetencies = async () => {
    if (!formData.subjectId) {
      setGeneralCompetencies([]);
      return;
    }

    try {
      // Obtener solo las competencias generales asociadas a la asignatura seleccionada
      const { data: generalRes, error: generalError } = await supabase
        .from('general_competencies')
        .select(`
          *,
          faculties(name),
          subject_general_competencies!inner(subject_id)
        `)
        .eq('subject_general_competencies.subject_id', formData.subjectId)
        .order('name');
      
      if (generalError) throw generalError;
      setGeneralCompetencies(generalRes || []);
    } catch (error) {
      console.error('Error fetching general competencies:', error);
      setGeneralCompetencies([]);
    }
  };

  const fetchSpecificCompetenciesForSubject = async () => {
    if (!formData.subjectId) {
      setSpecificCompetencies([]);
      return;
    }

    try {
      // Obtener la carrera de la asignatura seleccionada
      const { data: subjectData, error: subjectError } = await supabase
        .from('subjects')
        .select('career_id')
        .eq('id', formData.subjectId)
        .single();
      
      if (subjectError) throw subjectError;
      
      if (!subjectData?.career_id) {
        setSpecificCompetencies([]);
        return;
      }

      // Obtener las competencias específicas asociadas a esa carrera
      const { data: specificRes, error: specificError } = await supabase
        .from('specific_competencies')
        .select(`
          *,
          career_specific_competencies!inner(career_id)
        `)
        .eq('career_specific_competencies.career_id', subjectData.career_id)
        .order('name');
      
      if (specificError) throw specificError;
      setSpecificCompetencies(specificRes || []);
    } catch (error) {
      console.error('Error fetching specific competencies:', error);
      setSpecificCompetencies([]);
    }
  };

  const loadSyllabusData = async () => {
    if (!editingSyllabus) return;
    
    try {
      // Cargar datos básicos del syllabus
      setFormData({
        subjectId: editingSyllabus.subject_id || '',
        contactHours: editingSyllabus.contact_hours?.toString() || '',
        practicalExperimentalHours: editingSyllabus.practical_experimental_hours?.toString() || '',
        autonomousLearningHours: editingSyllabus.autonomous_learning_hours?.toString() || '',
        modalidad: editingSyllabus.modalidad || 'presencial',
      });

      // Cargar competencias generales seleccionadas
      const { data: generalCompData, error: generalError } = await supabase
        .from('syllabus_general_competencies')
        .select('general_competency_id, contribution_level')
        .eq('syllabus_id', editingSyllabus.id);
      
      if (!generalError && generalCompData) {
        const generalCompMap: {[key: string]: string} = {};
        generalCompData.forEach(comp => {
          generalCompMap[comp.general_competency_id] = comp.contribution_level;
        });
        setSelectedGeneralCompetencies(generalCompMap);
      }

      // Cargar competencias específicas seleccionadas
      const { data: specificCompData, error: specificError } = await supabase
        .from('syllabus_specific_competencies')
        .select('specific_competency_id, contribution_level')
        .eq('syllabus_id', editingSyllabus.id);
      
      if (!specificError && specificCompData) {
        const specificCompMap: {[key: string]: string} = {};
        specificCompData.forEach(comp => {
          specificCompMap[comp.specific_competency_id] = comp.contribution_level;
        });
        setSelectedSpecificCompetencies(specificCompMap);
      }

      // Cargar resultados de aprendizaje seleccionados
      const { data: learningOutcomesData, error: learningError } = await supabase
        .from('syllabus_learning_outcomes')
        .select('learning_outcome_id')
        .eq('syllabus_id', editingSyllabus.id);
      
      if (!learningError && learningOutcomesData) {
        setSelectedLearningOutcomes(learningOutcomesData.map(lo => lo.learning_outcome_id));
      }

      // Cargar bibliografía
      const { data: bibliographyData, error: bibError } = await supabase
        .from('bibliography')
        .select('*')
        .eq('syllabus_id', editingSyllabus.id);
      
      if (!bibError && bibliographyData && bibliographyData.length > 0) {
        setBibliography(bibliographyData.map(bib => ({
          title: bib.title,
          author: bib.author,
          year: bib.year?.toString() || '',
          publisher: bib.publisher || '',
          type: bib.type as 'basica' | 'complementaria'
        })));
      }
      
    } catch (error) {
      console.error('Error loading syllabus data:', error);
    }
  };

  const toggleLearningOutcome = (outcomeId: string) => {
    setSelectedLearningOutcomes(prev => {
      if (prev.includes(outcomeId)) {
        return prev.filter(id => id !== outcomeId);
      } else {
        return [...prev, outcomeId];
      }
    });
  };

  const addBibliography = () => {
    setBibliography([...bibliography, { title: "", author: "", year: "", publisher: "", type: "basica" as "basica" | "complementaria" }]);
  };

  const removeBibliography = (index: number) => {
    if (bibliography.length > 1) {
      setBibliography(bibliography.filter((_, i) => i !== index));
    }
  };

  const updateBibliography = (index: number, field: string, value: string) => {
    const updated = [...bibliography];
    updated[index] = { ...updated[index], [field]: value };
    setBibliography(updated);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (viewOnly) return;
    
    setIsLoading(true);
    
    try {
      let syllabusId: string;

      if (editingSyllabus) {
        // Actualizar syllabus existente
        const { error: syllabusError } = await supabase
          .from('syllabus')
          .update({
            subject_id: formData.subjectId,
            contribution_to_career: selectedSubject?.contribution_to_career || '',
            contact_hours: parseInt(formData.contactHours),
            practical_experimental_hours: parseInt(formData.practicalExperimentalHours),
            autonomous_learning_hours: parseInt(formData.autonomousLearningHours),
            modalidad: formData.modalidad,
          })
          .eq('id', editingSyllabus.id);

        if (syllabusError) throw syllabusError;
        syllabusId = editingSyllabus.id;

        // Limpiar relaciones existentes
        await Promise.all([
          supabase.from('syllabus_learning_outcomes').delete().eq('syllabus_id', syllabusId),
          supabase.from('syllabus_general_competencies').delete().eq('syllabus_id', syllabusId),
          supabase.from('syllabus_specific_competencies').delete().eq('syllabus_id', syllabusId),
          supabase.from('bibliography').delete().eq('syllabus_id', syllabusId)
        ]);
      } else {
        // Crear el syllabus principal
        const { data: syllabusData, error: syllabusError } = await supabase
          .from('syllabus')
          .insert([{
            subject_id: formData.subjectId,
            contribution_to_career: selectedSubject?.contribution_to_career || '',
            contact_hours: parseInt(formData.contactHours),
            practical_experimental_hours: parseInt(formData.practicalExperimentalHours),
            autonomous_learning_hours: parseInt(formData.autonomousLearningHours),
            modalidad: formData.modalidad,
            created_by: (await supabase.auth.getUser()).data.user?.id
          }])
          .select()
          .single();

        if (syllabusError) throw syllabusError;
        syllabusId = syllabusData.id;
      }

      // Vincular learning outcomes seleccionados al syllabus
      if (selectedLearningOutcomes.length > 0) {
        const { error: learningError } = await supabase
          .from('syllabus_learning_outcomes')
          .insert(
            selectedLearningOutcomes.map(learningOutcomeId => ({
              syllabus_id: syllabusId,
              learning_outcome_id: learningOutcomeId
            }))
          );

        if (learningError) throw learningError;
      }

      // Vincular competencias generales con nivel de aporte
      const generalCompetenciesToInsert = Object.entries(selectedGeneralCompetencies).map(([competencyId, level]) => ({
        syllabus_id: syllabusId,
        general_competency_id: competencyId,
        contribution_level: level as "bajo" | "medio" | "alto"
      }));

      if (generalCompetenciesToInsert.length > 0) {
        const { error: generalError } = await supabase
          .from('syllabus_general_competencies')
          .insert(generalCompetenciesToInsert);

        if (generalError) throw generalError;
      }

      // Vincular competencias específicas con nivel de aporte
      const specificCompetenciesToInsert = Object.entries(selectedSpecificCompetencies).map(([competencyId, level]) => ({
        syllabus_id: syllabusId,
        specific_competency_id: competencyId,
        contribution_level: level as "bajo" | "medio" | "alto"
      }));

      if (specificCompetenciesToInsert.length > 0) {
        const { error: specificError } = await supabase
          .from('syllabus_specific_competencies')
          .insert(specificCompetenciesToInsert);

        if (specificError) throw specificError;
      }

      // Insertar bibliography
      const validBibliography = bibliography.filter(bib => bib.title.trim() !== "" && bib.author.trim() !== "");
      if (validBibliography.length > 0) {
        const { error: bibError } = await supabase
          .from('bibliography')
          .insert(
            validBibliography.map(bib => ({
              syllabus_id: syllabusId,
              title: bib.title,
              author: bib.author,
              year: bib.year ? parseInt(bib.year) : null,
              publisher: bib.publisher || null,
              type: bib.type
            }))
          );

        if (bibError) throw bibError;
      }

      toast({
        title: editingSyllabus ? "Syllabus actualizado" : "Syllabus guardado",
        description: editingSyllabus ? "El syllabus ha sido actualizado exitosamente." : "El syllabus ha sido guardado exitosamente.",
      });
      
      onClose();
    } catch (error) {
      console.error('Error creating syllabus:', error);
      toast({
        title: "Error",
        description: "No se pudo guardar el syllabus. Inténtalo de nuevo.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>
            {viewOnly ? 'Ver Syllabus' : editingSyllabus ? 'Editar Syllabus' : 'Crear Nuevo Syllabus'}
          </CardTitle>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Información básica */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="subject">Asignatura</Label>
               <Select value={formData.subjectId} onValueChange={(value) => setFormData({...formData, subjectId: value})} disabled={viewOnly}>
                 <SelectTrigger>
                   <SelectValue placeholder="Selecciona una asignatura" />
                 </SelectTrigger>
                 <SelectContent>
                   {subjects.map((subject) => (
                     <SelectItem key={subject.id} value={subject.id}>
                       {subject.name} - {subject.code} ({subject.careers?.name || 'Sin carrera'})
                     </SelectItem>
                   ))}
                 </SelectContent>
               </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="modalidad">Modalidad</Label>
               <Select value={formData.modalidad} onValueChange={(value) => setFormData({...formData, modalidad: value})} disabled={viewOnly}>
                 <SelectTrigger>
                   <SelectValue placeholder="Selecciona modalidad" />
                 </SelectTrigger>
                 <SelectContent>
                   <SelectItem value="presencial">Presencial</SelectItem>
                   <SelectItem value="online">Online</SelectItem>
                 </SelectContent>
               </Select>
            </div>
          </div>

          {/* Mostrar contribución a la carrera si hay asignatura seleccionada */}
          {selectedSubject?.contribution_to_career && (
            <div className="space-y-2">
              <Label>Contribución de la asignatura a la carrera</Label>
              <div className="p-4 bg-gray-50 rounded-lg">
                <p className="text-sm text-gray-700">{selectedSubject.contribution_to_career}</p>
              </div>
            </div>
          )}

          {/* Horas */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="contactHours">Horas en contacto con docente (CD)</Label>
               <Input
                 id="contactHours"
                 type="number"
                 min="0"
                 value={formData.contactHours}
                 onChange={(e) => setFormData({...formData, contactHours: e.target.value})}
                 required
                 readOnly={viewOnly}
               />
            </div>
            <div className="space-y-2">
              <Label htmlFor="practicalHours">Horas práctico-experimental (PE)</Label>
               <Input
                 id="practicalHours"
                 type="number"
                 min="0"
                 value={formData.practicalExperimentalHours}
                 onChange={(e) => setFormData({...formData, practicalExperimentalHours: e.target.value})}
                 required
                 readOnly={viewOnly}
               />
            </div>
            <div className="space-y-2">
              <Label htmlFor="autonomousHours">Horas de aprendizaje autónomo (AA)</Label>
               <Input
                 id="autonomousHours"
                 type="number"
                 min="0"
                 value={formData.autonomousLearningHours}
                 onChange={(e) => setFormData({...formData, autonomousLearningHours: e.target.value})}
                 required
                 readOnly={viewOnly}
               />
            </div>
          </div>

          {/* Resultados de aprendizaje */}
          {formData.subjectId && (
            <div className="space-y-4">
              <Label>Resultados de aprendizaje (RDA)</Label>
              {availableLearningOutcomes.length === 0 ? (
                <div className="p-4 border rounded-lg">
                  <p className="text-muted-foreground text-sm">
                    No hay resultados de aprendizaje definidos para esta asignatura.
                    Ve al Panel de Administración → Asignaturas para definirlos.
                  </p>
                </div>
              ) : (
                <div className="space-y-2">
                  {availableLearningOutcomes.map((outcome, index) => (
                    <div key={outcome.id} className="flex items-start gap-3 p-3 border rounded-lg">
                       <input
                         type="checkbox"
                         id={`outcome-${outcome.id}`}
                         checked={selectedLearningOutcomes.includes(outcome.id)}
                         onChange={() => !viewOnly && toggleLearningOutcome(outcome.id)}
                         disabled={viewOnly}
                         className="mt-1"
                       />
                      <div className="flex-1">
                        <label htmlFor={`outcome-${outcome.id}`} className="text-sm font-medium cursor-pointer">
                          RDA {index + 1}
                        </label>
                        <p className="text-sm text-muted-foreground">{outcome.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Competencias */}
          <div className="space-y-6">
            {/* Competencias Generales */}
            <div className="space-y-4">
              <Label>Competencias Generales</Label>
              {generalCompetencies.length === 0 ? (
                <div className="p-4 border rounded-lg">
                  <p className="text-muted-foreground text-sm">
                    No hay competencias generales definidas.
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {generalCompetencies.map((competency) => (
                    <div key={competency.id} className="flex items-center gap-4 p-3 border rounded-lg">
                       <input
                         type="checkbox"
                         id={`gen-comp-${competency.id}`}
                         checked={!!selectedGeneralCompetencies[competency.id]}
                         onChange={(e) => {
                           if (!viewOnly) {
                             if (e.target.checked) {
                               setSelectedGeneralCompetencies(prev => ({
                                 ...prev,
                                 [competency.id]: 'medio'
                               }));
                             } else {
                               const updated = {...selectedGeneralCompetencies};
                               delete updated[competency.id];
                               setSelectedGeneralCompetencies(updated);
                             }
                           }
                         }}
                         disabled={viewOnly}
                         className="mt-1"
                       />
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <p className="text-sm font-medium">{competency.faculties?.name || 'Transversal'}</p>
                          {competency.code && (
                            <span className="text-xs bg-gray-100 px-2 py-1 rounded">{competency.code}</span>
                          )}
                        </div>
                        {competency.name && (
                          <p className="text-sm font-medium">{competency.name}</p>
                        )}
                        <p className="text-sm text-muted-foreground">{competency.description}</p>
                      </div>
                      {selectedGeneralCompetencies[competency.id] && (
                         <Select
                           value={selectedGeneralCompetencies[competency.id]}
                           onValueChange={(value) => {
                             if (!viewOnly) {
                               setSelectedGeneralCompetencies(prev => ({
                                 ...prev,
                                 [competency.id]: value
                               }));
                             }
                           }}
                           disabled={viewOnly}
                         >
                          <SelectTrigger className="w-32">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="bajo">Bajo</SelectItem>
                            <SelectItem value="medio">Medio</SelectItem>
                            <SelectItem value="alto">Alto</SelectItem>
                          </SelectContent>
                        </Select>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Competencias Específicas */}
            <div className="space-y-4">
              <Label>Competencias Específicas</Label>
              {specificCompetencies.length === 0 ? (
                <div className="p-4 border rounded-lg">
                  <p className="text-muted-foreground text-sm">
                    No hay competencias específicas definidas.
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {specificCompetencies.map((competency) => (
                    <div key={competency.id} className="flex items-center gap-4 p-3 border rounded-lg">
                       <input
                         type="checkbox"
                         id={`spec-comp-${competency.id}`}
                         checked={!!selectedSpecificCompetencies[competency.id]}
                         onChange={(e) => {
                           if (!viewOnly) {
                             if (e.target.checked) {
                               setSelectedSpecificCompetencies(prev => ({
                                 ...prev,
                                 [competency.id]: 'medio'
                               }));
                             } else {
                               const updated = {...selectedSpecificCompetencies};
                               delete updated[competency.id];
                               setSelectedSpecificCompetencies(updated);
                             }
                           }
                         }}
                         disabled={viewOnly}
                         className="mt-1"
                       />
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-sm font-medium">Específica</span>
                          {competency.code && (
                            <span className="text-xs bg-gray-100 px-2 py-1 rounded">{competency.code}</span>
                          )}
                        </div>
                        {competency.name && (
                          <p className="text-sm font-medium">{competency.name}</p>
                        )}
                        <p className="text-sm text-muted-foreground">{competency.description}</p>
                      </div>
                      {selectedSpecificCompetencies[competency.id] && (
                         <Select
                           value={selectedSpecificCompetencies[competency.id]}
                           onValueChange={(value) => {
                             if (!viewOnly) {
                               setSelectedSpecificCompetencies(prev => ({
                                 ...prev,
                                 [competency.id]: value
                               }));
                             }
                           }}
                           disabled={viewOnly}
                         >
                          <SelectTrigger className="w-32">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="bajo">Bajo</SelectItem>
                            <SelectItem value="medio">Medio</SelectItem>
                            <SelectItem value="alto">Alto</SelectItem>
                          </SelectContent>
                        </Select>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Bibliografía */}
          <div className="space-y-4">
             <div className="flex items-center justify-between">
               <Label>Bibliografía de referencia</Label>
               {!viewOnly && (
                 <Button type="button" variant="outline" size="sm" onClick={addBibliography}>
                   <Plus className="h-4 w-4 mr-2" />
                   Agregar
                 </Button>
               )}
             </div>
            {bibliography.map((bib, index) => (
              <Card key={index} className="p-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Título</Label>
                     <Input
                       placeholder="Título del libro/artículo"
                       value={bib.title}
                       onChange={(e) => updateBibliography(index, "title", e.target.value)}
                       readOnly={viewOnly}
                     />
                  </div>
                  <div className="space-y-2">
                    <Label>Autor</Label>
                     <Input
                       placeholder="Nombre del autor"
                       value={bib.author}
                       onChange={(e) => updateBibliography(index, "author", e.target.value)}
                       readOnly={viewOnly}
                     />
                  </div>
                  <div className="space-y-2">
                    <Label>Año</Label>
                     <Input
                       placeholder="Año de publicación"
                       value={bib.year}
                       onChange={(e) => updateBibliography(index, "year", e.target.value)}
                       readOnly={viewOnly}
                     />
                  </div>
                  <div className="space-y-2">
                    <Label>Editorial</Label>
                     <Input
                       placeholder="Editorial"
                       value={bib.publisher}
                       onChange={(e) => updateBibliography(index, "publisher", e.target.value)}
                       readOnly={viewOnly}
                     />
                  </div>
                  <div className="space-y-2">
                    <Label>Tipo</Label>
                     <Select
                       value={bib.type}
                       onValueChange={(value) => updateBibliography(index, "type", value)}
                       disabled={viewOnly}
                     >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="basica">Básica</SelectItem>
                        <SelectItem value="complementaria">Complementaria</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                   {bibliography.length > 1 && !viewOnly && (
                     <div className="flex items-end">
                       <Button
                         type="button"
                         variant="outline"
                         size="sm"
                         onClick={() => removeBibliography(index)}
                       >
                         <X className="h-4 w-4" />
                       </Button>
                     </div>
                   )}
                </div>
              </Card>
            ))}
          </div>

           {/* Botones de acción */}
           {!viewOnly && (
             <div className="flex justify-end gap-2 pt-6">
               <Button type="button" variant="outline" onClick={onClose}>
                 Cancelar
               </Button>
               <Button type="submit" disabled={isLoading}>
                 {isLoading ? "Guardando..." : editingSyllabus ? "Actualizar Syllabus" : "Guardar Syllabus"}
               </Button>
             </div>
           )}
        </form>
      </CardContent>
    </Card>
  );
};