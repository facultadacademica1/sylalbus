import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { FileText, Edit, Trash2, Eye, Search } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

interface SyllabusData {
  id: string;
  subjectName: string;
  subjectCode: string;
  career: string;
  faculty: string;
  modalidad: string;
  updatedAt: string;
}

interface SyllabusListProps {
  onEdit?: (syllabusId: string) => void;
  onView?: (syllabusId: string) => void;
}

export const SyllabusList = ({ onEdit, onView }: SyllabusListProps = {}) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [facultyFilter, setFacultyFilter] = useState("");
  const [careerFilter, setCareerFilter] = useState("");
  const [syllabusData, setSyllabusData] = useState<SyllabusData[]>([]);
  const [loading, setLoading] = useState(true);
  const [faculties, setFaculties] = useState<string[]>([]);
  const [careers, setCareers] = useState<string[]>([]);
  const { toast } = useToast();

  useEffect(() => {
    fetchSyllabusData();
  }, []);

  const fetchSyllabusData = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('syllabus')
        .select(`
          id,
          updated_at,
          modalidad,
          subjects (
            name,
            code,
            careers (
              name,
              faculties (
                name
              )
            )
          )
        `)
        .order('updated_at', { ascending: false });

      if (error) throw error;

      const formattedData: SyllabusData[] = data?.map(item => ({
        id: item.id,
        subjectName: item.subjects?.name || 'Sin asignatura',
        subjectCode: item.subjects?.code || 'Sin código',
        career: item.subjects?.careers?.name || 'Sin carrera',
        faculty: item.subjects?.careers?.faculties?.name || 'Sin facultad',
        modalidad: item.modalidad || 'presencial',
        updatedAt: item.updated_at || new Date().toISOString(),
      })) || [];

      setSyllabusData(formattedData);

      // Extract unique faculties and careers for filters
      const uniqueFaculties = [...new Set(formattedData.map(item => item.faculty))];
      const uniqueCareers = [...new Set(formattedData.map(item => item.career))];
      setFaculties(uniqueFaculties);
      setCareers(uniqueCareers);

    } catch (error) {
      console.error('Error fetching syllabus data:', error);
      toast({
        title: "Error",
        description: "No se pudo cargar la lista de syllabus",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      const { error } = await supabase
        .from('syllabus')
        .delete()
        .eq('id', id);

      if (error) throw error;

      toast({
        title: "Éxito",
        description: "Syllabus eliminado correctamente",
      });

      fetchSyllabusData(); // Refresh the list
    } catch (error) {
      console.error('Error deleting syllabus:', error);
      toast({
        title: "Error",
        description: "No se pudo eliminar el syllabus",
        variant: "destructive",
      });
    }
  };

  const handleView = (id: string) => {
    if (onView) {
      onView(id);
    } else {
      toast({
        title: "Información",
        description: "Funcionalidad de visualización pendiente de implementar",
      });
    }
  };

  const handleEdit = (id: string) => {
    if (onEdit) {
      onEdit(id);
    } else {
      toast({
        title: "Información",
        description: "Funcionalidad de edición pendiente de implementar",
      });
    }
  };

  const filteredSyllabus = syllabusData.filter((syllabus) => {
    const matchesSearch = searchTerm === "" || 
      syllabus.subjectName.toLowerCase().includes(searchTerm.toLowerCase()) || 
      syllabus.subjectCode.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesFaculty = facultyFilter === "all" || facultyFilter === "" || syllabus.faculty === facultyFilter;
    const matchesCareer = careerFilter === "all" || careerFilter === "" || syllabus.career === careerFilter;
    
    return matchesSearch && matchesFaculty && matchesCareer;
  });

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('es-ES', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  if (loading) {
    return (
      <div className="space-y-4">
        <Card>
          <CardContent className="p-4">
            <div className="text-center">Cargando syllabus...</div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardContent className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar por nombre o código..."
                className="pl-8"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Select value={facultyFilter} onValueChange={setFacultyFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Filtrar por facultad" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas las facultades</SelectItem>
                {faculties.map((faculty) => (
                  <SelectItem key={faculty} value={faculty}>{faculty}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={careerFilter} onValueChange={setCareerFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Filtrar por carrera" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas las carreras</SelectItem>
                {careers.map((career) => (
                  <SelectItem key={career} value={career}>{career}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-4">
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[50px]"></TableHead>
                  <TableHead>Asignatura</TableHead>
                  <TableHead className="hidden md:table-cell">Código</TableHead>
                  <TableHead className="hidden md:table-cell">Carrera</TableHead>
                  <TableHead className="hidden md:table-cell">Facultad</TableHead>
                  <TableHead className="hidden md:table-cell">Actualizado</TableHead>
                  <TableHead className="text-right">Acciones</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredSyllabus.length > 0 ? (
                  filteredSyllabus.map((syllabus) => (
                    <TableRow key={syllabus.id}>
                      <TableCell>
                        <FileText className="h-5 w-5 text-muted-foreground" />
                      </TableCell>
                      <TableCell className="font-medium">{syllabus.subjectName}</TableCell>
                      <TableCell className="hidden md:table-cell">
                        <Badge variant="outline">{syllabus.subjectCode}</Badge>
                      </TableCell>
                      <TableCell className="hidden md:table-cell">{syllabus.career}</TableCell>
                      <TableCell className="hidden md:table-cell">{syllabus.faculty}</TableCell>
                      <TableCell className="hidden md:table-cell">{formatDate(syllabus.updatedAt)}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button 
                            size="sm" 
                            variant="ghost" 
                            title="Ver"
                            onClick={() => handleView(syllabus.id)}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button 
                            size="sm" 
                            variant="ghost" 
                            title="Editar"
                            onClick={() => handleEdit(syllabus.id)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button size="sm" variant="ghost" title="Eliminar">
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>¿Estás seguro?</AlertDialogTitle>
                                <AlertDialogDescription>
                                  Esta acción no se puede deshacer. El syllabus será eliminado permanentemente.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancelar</AlertDialogCancel>
                                <AlertDialogAction onClick={() => handleDelete(syllabus.id)}>
                                  Eliminar
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={7} className="h-24 text-center">
                      No se encontraron resultados.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};