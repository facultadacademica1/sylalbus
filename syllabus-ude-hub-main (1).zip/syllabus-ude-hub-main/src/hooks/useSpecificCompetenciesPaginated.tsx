import { useState, useEffect, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface Career {
  id: string;
  name: string;
  faculty_id: string;
}

interface Faculty {
  id: string;
  name: string;
}

interface SpecificCompetencyWithRelations {
  id: string;
  code?: string;
  name?: string;
  description: string;
  created_at: string;
  updated_at: string;
  career_count?: number;
  career_names?: string[];
}

interface PaginationInfo {
  page: number;
  pageSize: number;
  total: number;
  totalPages: number;
}

interface UseSpecificCompetenciesPaginatedReturn {
  competencies: SpecificCompetencyWithRelations[];
  pagination: PaginationInfo;
  isLoading: boolean;
  searchTerm: string;
  setSearchTerm: (term: string) => void;
  careerFilter: string;
  setCareerFilter: (filter: string) => void;
  facultyFilter: string;
  setFacultyFilter: (filter: string) => void;
  sortBy: string;
  setSortBy: (field: string) => void;
  sortOrder: 'asc' | 'desc';
  setSortOrder: (order: 'asc' | 'desc') => void;
  goToPage: (page: number) => void;
  refreshCompetencies: () => Promise<void>;
  deleteCompetency: (id: string, name: string) => Promise<void>;
}

export const useSpecificCompetenciesPaginated = (pageSize: number = 20): UseSpecificCompetenciesPaginatedReturn => {
  const { toast } = useToast();
  const [competencies, setCompetencies] = useState<SpecificCompetencyWithRelations[]>([]);
  const [pagination, setPagination] = useState<PaginationInfo>({
    page: 1,
    pageSize,
    total: 0,
    totalPages: 0
  });
  const [isLoading, setIsLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [debouncedSearchTerm, setDebouncedSearchTerm] = useState("");
  const [careerFilter, setCareerFilter] = useState("all");
  const [facultyFilter, setFacultyFilter] = useState("all");
  const [sortBy, setSortBy] = useState("description");
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');

  // Debounce search term
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearchTerm(searchTerm);
    }, 300);

    return () => clearTimeout(timer);
  }, [searchTerm]);

  // Reset to first page when filters change
  useEffect(() => {
    if (pagination.page !== 1) {
      setPagination(prev => ({ ...prev, page: 1 }));
    }
  }, [debouncedSearchTerm, careerFilter, facultyFilter, sortBy, sortOrder]);

  // Fetch competencies when dependencies change
  useEffect(() => {
    fetchCompetencies();
  }, [pagination.page, pageSize, debouncedSearchTerm, careerFilter, facultyFilter, sortBy, sortOrder]);

  const fetchCompetencies = useCallback(async () => {
    setIsLoading(true);
    try {
      const from = (pagination.page - 1) * pageSize;
      const to = from + pageSize - 1;

      let query = supabase
        .from('specific_competencies')
        .select('*', { count: 'exact' });

      // Apply search filter
      if (debouncedSearchTerm) {
        query = query.or(`name.ilike.%${debouncedSearchTerm}%,description.ilike.%${debouncedSearchTerm}%`);
      }

      // Apply career filter (through relationship)
      if (careerFilter && careerFilter !== "all") {
        const { data: competencyIds } = await supabase
          .from('career_specific_competencies')
          .select('specific_competency_id')
          .eq('career_id', careerFilter);
        
        if (competencyIds && competencyIds.length > 0) {
          const ids = competencyIds.map(item => item.specific_competency_id);
          query = query.in('id', ids);
        } else {
          // No competencies for this career
          setCompetencies([]);
          setPagination(prev => ({ ...prev, total: 0, totalPages: 0 }));
          setIsLoading(false);
          return;
        }
      }

      // Apply faculty filter (through career relationship)
      if (facultyFilter && facultyFilter !== "all") {
        const { data: careers } = await supabase
          .from('careers')
          .select('id')
          .eq('faculty_id', facultyFilter);
        
        if (careers && careers.length > 0) {
          const careerIds = careers.map(career => career.id);
          const { data: competencyIds } = await supabase
            .from('career_specific_competencies')
            .select('specific_competency_id')
            .in('career_id', careerIds);
          
          if (competencyIds && competencyIds.length > 0) {
            const ids = competencyIds.map(item => item.specific_competency_id);
            query = query.in('id', ids);
          } else {
            // No competencies for this faculty
            setCompetencies([]);
            setPagination(prev => ({ ...prev, total: 0, totalPages: 0 }));
            setIsLoading(false);
            return;
          }
        }
      }

      // Apply sorting
      query = query.order(sortBy, { ascending: sortOrder === 'asc' });

      // Apply pagination
      query = query.range(from, to);

      const { data: competenciesData, error, count } = await query;

      if (error) throw error;

      // Fetch career relationships for each competency
      const competenciesWithRelations: SpecificCompetencyWithRelations[] = await Promise.all(
        (competenciesData || []).map(async (competency) => {
          const { data: careerRelations } = await supabase
            .from('career_specific_competencies')
            .select(`
              careers!inner (
                id,
                name
              )
            `)
            .eq('specific_competency_id', competency.id);

          const careerNames = careerRelations?.map(rel => rel.careers.name) || [];
          
          return {
            ...competency,
            career_count: careerNames.length,
            career_names: careerNames
          };
        })
      );

      setCompetencies(competenciesWithRelations);
      setPagination(prev => ({
        ...prev,
        total: count || 0,
        totalPages: Math.ceil((count || 0) / pageSize)
      }));

    } catch (error) {
      console.error('Error fetching competencies:', error);
      toast({
        title: "Error",
        description: "No se pudieron cargar las competencias específicas",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  }, [pagination.page, pageSize, debouncedSearchTerm, careerFilter, facultyFilter, sortBy, sortOrder, toast]);

  const goToPage = (page: number) => {
    setPagination(prev => ({ ...prev, page }));
  };

  const refreshCompetencies = async () => {
    await fetchCompetencies();
  };

  const deleteCompetency = async (id: string, name: string) => {
    if (!confirm(`¿Está seguro de que desea eliminar la competencia específica "${name}"?`)) {
      return;
    }

    try {
      // Delete career relationships first
      const { error: relationError } = await supabase
        .from('career_specific_competencies')
        .delete()
        .eq('specific_competency_id', id);

      if (relationError) throw relationError;

      // Delete the competency
      const { error: competencyError } = await supabase
        .from('specific_competencies')
        .delete()
        .eq('id', id);

      if (competencyError) throw competencyError;

      toast({
        title: "Éxito",
        description: `Competencia específica "${name}" eliminada correctamente`,
      });

      await refreshCompetencies();
    } catch (error) {
      console.error('Error deleting competency:', error);
      toast({
        title: "Error",
        description: "No se pudo eliminar la competencia específica",
        variant: "destructive",
      });
    }
  };

  return {
    competencies,
    pagination,
    isLoading,
    searchTerm,
    setSearchTerm,
    careerFilter,
    setCareerFilter,
    facultyFilter,
    setFacultyFilter,
    sortBy,
    setSortBy,
    sortOrder,
    setSortOrder,
    goToPage,
    refreshCompetencies,
    deleteCompetency
  };
};