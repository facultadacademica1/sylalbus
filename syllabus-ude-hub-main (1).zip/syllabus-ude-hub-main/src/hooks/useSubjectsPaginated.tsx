import { useState, useEffect, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface Subject {
  id: string;
  name: string;
  code: string;
  contribution_to_career?: string;
  contents?: string[];
  careers?: { name: string; id: string };
  learning_outcomes_count: number;
  general_competencies_count: number;
}

interface PaginationInfo {
  page: number;
  pageSize: number;
  total: number;
  totalPages: number;
}

interface UseSubjectsPaginatedReturn {
  subjects: Subject[];
  pagination: PaginationInfo;
  isLoading: boolean;
  searchTerm: string;
  careerFilter: string;
  facultyFilter: string;
  sortBy: string;
  sortOrder: 'asc' | 'desc';
  setSearchTerm: (term: string) => void;
  setCareerFilter: (career: string) => void;
  setFacultyFilter: (faculty: string) => void;
  setSortBy: (field: string) => void;
  setSortOrder: (order: 'asc' | 'desc') => void;
  goToPage: (page: number) => void;
  refreshSubjects: () => Promise<void>;
  deleteSubject: (id: string, name: string) => Promise<void>;
}

export const useSubjectsPaginated = (pageSize: number = 25): UseSubjectsPaginatedReturn => {
  const { toast } = useToast();
  
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [debouncedSearchTerm, setDebouncedSearchTerm] = useState("");
  const [careerFilter, setCareerFilter] = useState("all");
  const [facultyFilter, setFacultyFilter] = useState("");
  const [sortBy, setSortBy] = useState("name");
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');
  const [pagination, setPagination] = useState<PaginationInfo>({
    page: 1,
    pageSize,
    total: 0,
    totalPages: 0
  });

  // Debounce search term
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearchTerm(searchTerm);
    }, 300);

    return () => clearTimeout(timer);
  }, [searchTerm]);

  // Reset to page 1 when filters change
  useEffect(() => {
    setPagination(prev => ({ ...prev, page: 1 }));
  }, [debouncedSearchTerm, careerFilter, facultyFilter, sortBy, sortOrder]);

  const fetchSubjects = useCallback(async () => {
    setIsLoading(true);
    try {
      // Build the query with filters
      let query = supabase
        .from('subjects')
        .select(`
          id,
          name,
          code,
          contribution_to_career,
          contents,
          careers(name, id)
        `, { count: 'exact' });

      // Apply search filter
      if (debouncedSearchTerm.trim()) {
        query = query.or(`name.ilike.%${debouncedSearchTerm}%,code.ilike.%${debouncedSearchTerm}%,careers.name.ilike.%${debouncedSearchTerm}%`);
      }

      // Apply career filter
      if (careerFilter && careerFilter !== "all") {
        query = query.eq('career_id', careerFilter);
      }

      // Apply sorting
      const ascending = sortOrder === 'asc';
      if (sortBy === 'career') {
        query = query.order('name', { foreignTable: 'careers', ascending });
      } else {
        query = query.order(sortBy, { ascending });
      }

      // Apply pagination
      const from = (pagination.page - 1) * pageSize;
      const to = from + pageSize - 1;
      query = query.range(from, to);

      const { data, error, count } = await query;

      if (error) throw error;

      // Fetch counts for each subject efficiently using a single query
      const subjectIds = data?.map(s => s.id) || [];
      
      if (subjectIds.length > 0) {
        const [outcomesData, competenciesData] = await Promise.all([
          supabase
            .from('learning_outcomes')
            .select('subject_id')
            .in('subject_id', subjectIds),
          supabase
            .from('subject_general_competencies')
            .select('subject_id')
            .in('subject_id', subjectIds)
        ]);

        // Count by subject_id
        const outcomesCounts = (outcomesData.data || []).reduce((acc, item) => {
          acc[item.subject_id] = (acc[item.subject_id] || 0) + 1;
          return acc;
        }, {} as Record<string, number>);

        const competenciesCounts = (competenciesData.data || []).reduce((acc, item) => {
          acc[item.subject_id] = (acc[item.subject_id] || 0) + 1;
          return acc;
        }, {} as Record<string, number>);

        const subjectsWithCounts = (data || []).map(subject => ({
          ...subject,
          learning_outcomes_count: outcomesCounts[subject.id] || 0,
          general_competencies_count: competenciesCounts[subject.id] || 0
        }));

        setSubjects(subjectsWithCounts);
      } else {
        setSubjects([]);
      }

      setPagination(prev => ({
        ...prev,
        total: count || 0,
        totalPages: Math.ceil((count || 0) / pageSize)
      }));

    } catch (error) {
      console.error('Error fetching subjects:', error);
      toast({
        title: "Error",
        description: "No se pudieron cargar las asignaturas.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  }, [debouncedSearchTerm, careerFilter, facultyFilter, sortBy, sortOrder, pagination.page, pageSize, toast]);

  useEffect(() => {
    fetchSubjects();
  }, [fetchSubjects]);

  const goToPage = (page: number) => {
    setPagination(prev => ({ ...prev, page }));
  };

  const refreshSubjects = async () => {
    await fetchSubjects();
  };

  const deleteSubject = async (subjectId: string, subjectName: string) => {
    if (!confirm(`¿Estás seguro de eliminar la asignatura "${subjectName}"? Esta acción eliminará también todos sus resultados de aprendizaje asociados.`)) {
      return;
    }
    
    setIsLoading(true);
    try {
      // Delete related data first
      await Promise.all([
        supabase.from('learning_outcomes').delete().eq('subject_id', subjectId),
        supabase.from('subject_general_competencies').delete().eq('subject_id', subjectId)
      ]);

      // Delete the subject
      const { error } = await supabase
        .from('subjects')
        .delete()
        .eq('id', subjectId);

      if (error) throw error;

      toast({
        title: "Asignatura eliminada",
        description: "La asignatura ha sido eliminada exitosamente.",
      });
      
      await refreshSubjects();
    } catch (error) {
      console.error('Error deleting subject:', error);
      toast({
        title: "Error",
        description: "No se pudo eliminar la asignatura.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return {
    subjects,
    pagination,
    isLoading,
    searchTerm,
    careerFilter,
    facultyFilter,
    sortBy,
    sortOrder,
    setSearchTerm,
    setCareerFilter,
    setFacultyFilter,
    setSortBy,
    setSortOrder,
    goToPage,
    refreshSubjects,
    deleteSubject
  };
};