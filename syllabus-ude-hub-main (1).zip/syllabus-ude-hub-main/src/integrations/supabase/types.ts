export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instanciate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "12.2.12 (cd3cf9e)"
  }
  public: {
    Tables: {
      bibliography: {
        Row: {
          author: string
          created_at: string | null
          id: string
          publisher: string | null
          syllabus_id: string | null
          title: string
          type: Database["public"]["Enums"]["bibliography_type"]
          updated_at: string | null
          year: number | null
        }
        Insert: {
          author: string
          created_at?: string | null
          id?: string
          publisher?: string | null
          syllabus_id?: string | null
          title: string
          type: Database["public"]["Enums"]["bibliography_type"]
          updated_at?: string | null
          year?: number | null
        }
        Update: {
          author?: string
          created_at?: string | null
          id?: string
          publisher?: string | null
          syllabus_id?: string | null
          title?: string
          type?: Database["public"]["Enums"]["bibliography_type"]
          updated_at?: string | null
          year?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "bibliography_syllabus_id_fkey"
            columns: ["syllabus_id"]
            isOneToOne: false
            referencedRelation: "syllabus"
            referencedColumns: ["id"]
          },
        ]
      }
      career_specific_competencies: {
        Row: {
          career_id: string
          created_at: string
          id: string
          specific_competency_id: string
        }
        Insert: {
          career_id: string
          created_at?: string
          id?: string
          specific_competency_id: string
        }
        Update: {
          career_id?: string
          created_at?: string
          id?: string
          specific_competency_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "fk_career_specific_competencies_career"
            columns: ["career_id"]
            isOneToOne: false
            referencedRelation: "careers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fk_career_specific_competencies_specific_competency"
            columns: ["specific_competency_id"]
            isOneToOne: false
            referencedRelation: "specific_competencies"
            referencedColumns: ["id"]
          },
        ]
      }
      careers: {
        Row: {
          created_at: string | null
          description: string | null
          faculty_id: string | null
          id: string
          name: string
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          description?: string | null
          faculty_id?: string | null
          id?: string
          name: string
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          description?: string | null
          faculty_id?: string | null
          id?: string
          name?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "careers_faculty_id_fkey"
            columns: ["faculty_id"]
            isOneToOne: false
            referencedRelation: "faculties"
            referencedColumns: ["id"]
          },
        ]
      }
      faculties: {
        Row: {
          created_at: string | null
          description: string | null
          id: string
          name: string
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          description?: string | null
          id?: string
          name: string
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          description?: string | null
          id?: string
          name?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      general_competencies: {
        Row: {
          code: string | null
          created_at: string | null
          description: string
          faculty_id: string | null
          id: string
          name: string | null
          updated_at: string | null
        }
        Insert: {
          code?: string | null
          created_at?: string | null
          description: string
          faculty_id?: string | null
          id?: string
          name?: string | null
          updated_at?: string | null
        }
        Update: {
          code?: string | null
          created_at?: string | null
          description?: string
          faculty_id?: string | null
          id?: string
          name?: string | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "general_competencies_faculty_id_fkey"
            columns: ["faculty_id"]
            isOneToOne: false
            referencedRelation: "faculties"
            referencedColumns: ["id"]
          },
        ]
      }
      learning_outcomes: {
        Row: {
          code: string | null
          created_at: string | null
          description: string
          id: string
          subject_id: string | null
          syllabus_id: string | null
          updated_at: string | null
        }
        Insert: {
          code?: string | null
          created_at?: string | null
          description: string
          id?: string
          subject_id?: string | null
          syllabus_id?: string | null
          updated_at?: string | null
        }
        Update: {
          code?: string | null
          created_at?: string | null
          description?: string
          id?: string
          subject_id?: string | null
          syllabus_id?: string | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "learning_outcomes_subject_id_fkey"
            columns: ["subject_id"]
            isOneToOne: false
            referencedRelation: "subjects"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "learning_outcomes_syllabus_id_fkey"
            columns: ["syllabus_id"]
            isOneToOne: false
            referencedRelation: "syllabus"
            referencedColumns: ["id"]
          },
        ]
      }
      specific_competencies: {
        Row: {
          code: string | null
          created_at: string | null
          description: string
          id: string
          name: string | null
          updated_at: string | null
        }
        Insert: {
          code?: string | null
          created_at?: string | null
          description: string
          id?: string
          name?: string | null
          updated_at?: string | null
        }
        Update: {
          code?: string | null
          created_at?: string | null
          description?: string
          id?: string
          name?: string | null
          updated_at?: string | null
        }
        Relationships: []
      }
      subject_general_competencies: {
        Row: {
          created_at: string
          general_competency_id: string
          id: string
          subject_id: string
        }
        Insert: {
          created_at?: string
          general_competency_id: string
          id?: string
          subject_id: string
        }
        Update: {
          created_at?: string
          general_competency_id?: string
          id?: string
          subject_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "fk_subject_general_competencies_general_competency"
            columns: ["general_competency_id"]
            isOneToOne: false
            referencedRelation: "general_competencies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fk_subject_general_competencies_subject"
            columns: ["subject_id"]
            isOneToOne: false
            referencedRelation: "subjects"
            referencedColumns: ["id"]
          },
        ]
      }
      subject_learning_outcomes: {
        Row: {
          created_at: string | null
          id: string
          learning_outcome_id: string
          subject_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          learning_outcome_id: string
          subject_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          learning_outcome_id?: string
          subject_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "subject_learning_outcomes_learning_outcome_id_fkey"
            columns: ["learning_outcome_id"]
            isOneToOne: false
            referencedRelation: "learning_outcomes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "subject_learning_outcomes_subject_id_fkey"
            columns: ["subject_id"]
            isOneToOne: false
            referencedRelation: "subjects"
            referencedColumns: ["id"]
          },
        ]
      }
      subjects: {
        Row: {
          career_id: string | null
          code: string
          contents: string[] | null
          contribution_to_career: string | null
          created_at: string | null
          id: string
          name: string
          updated_at: string | null
        }
        Insert: {
          career_id?: string | null
          code: string
          contents?: string[] | null
          contribution_to_career?: string | null
          created_at?: string | null
          id?: string
          name: string
          updated_at?: string | null
        }
        Update: {
          career_id?: string | null
          code?: string
          contents?: string[] | null
          contribution_to_career?: string | null
          created_at?: string | null
          id?: string
          name?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "subjects_career_id_fkey"
            columns: ["career_id"]
            isOneToOne: false
            referencedRelation: "careers"
            referencedColumns: ["id"]
          },
        ]
      }
      syllabus: {
        Row: {
          autonomous_learning_hours: number
          contact_hours: number
          contribution_to_career: string
          created_at: string | null
          created_by: string | null
          id: string
          modalidad: string | null
          practical_experimental_hours: number
          subject_id: string | null
          updated_at: string | null
        }
        Insert: {
          autonomous_learning_hours: number
          contact_hours: number
          contribution_to_career: string
          created_at?: string | null
          created_by?: string | null
          id?: string
          modalidad?: string | null
          practical_experimental_hours: number
          subject_id?: string | null
          updated_at?: string | null
        }
        Update: {
          autonomous_learning_hours?: number
          contact_hours?: number
          contribution_to_career?: string
          created_at?: string | null
          created_by?: string | null
          id?: string
          modalidad?: string | null
          practical_experimental_hours?: number
          subject_id?: string | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "syllabus_subject_id_fkey"
            columns: ["subject_id"]
            isOneToOne: false
            referencedRelation: "subjects"
            referencedColumns: ["id"]
          },
        ]
      }
      syllabus_general_competencies: {
        Row: {
          contribution_level: Database["public"]["Enums"]["contribution_level"]
          general_competency_id: string | null
          id: string
          syllabus_id: string | null
        }
        Insert: {
          contribution_level: Database["public"]["Enums"]["contribution_level"]
          general_competency_id?: string | null
          id?: string
          syllabus_id?: string | null
        }
        Update: {
          contribution_level?: Database["public"]["Enums"]["contribution_level"]
          general_competency_id?: string | null
          id?: string
          syllabus_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "syllabus_general_competencies_general_competency_id_fkey"
            columns: ["general_competency_id"]
            isOneToOne: false
            referencedRelation: "general_competencies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "syllabus_general_competencies_syllabus_id_fkey"
            columns: ["syllabus_id"]
            isOneToOne: false
            referencedRelation: "syllabus"
            referencedColumns: ["id"]
          },
        ]
      }
      syllabus_learning_outcomes: {
        Row: {
          created_at: string | null
          id: string
          learning_outcome_id: string
          syllabus_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          learning_outcome_id: string
          syllabus_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          learning_outcome_id?: string
          syllabus_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "syllabus_learning_outcomes_learning_outcome_id_fkey"
            columns: ["learning_outcome_id"]
            isOneToOne: false
            referencedRelation: "learning_outcomes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "syllabus_learning_outcomes_syllabus_id_fkey"
            columns: ["syllabus_id"]
            isOneToOne: false
            referencedRelation: "syllabus"
            referencedColumns: ["id"]
          },
        ]
      }
      syllabus_specific_competencies: {
        Row: {
          contribution_level: Database["public"]["Enums"]["contribution_level"]
          id: string
          specific_competency_id: string | null
          syllabus_id: string | null
        }
        Insert: {
          contribution_level: Database["public"]["Enums"]["contribution_level"]
          id?: string
          specific_competency_id?: string | null
          syllabus_id?: string | null
        }
        Update: {
          contribution_level?: Database["public"]["Enums"]["contribution_level"]
          id?: string
          specific_competency_id?: string | null
          syllabus_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "syllabus_specific_competencies_specific_competency_id_fkey"
            columns: ["specific_competency_id"]
            isOneToOne: false
            referencedRelation: "specific_competencies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "syllabus_specific_competencies_syllabus_id_fkey"
            columns: ["syllabus_id"]
            isOneToOne: false
            referencedRelation: "syllabus"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      bibliography_type: "basica" | "complementaria"
      contribution_level: "alto" | "medio" | "bajo"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      bibliography_type: ["basica", "complementaria"],
      contribution_level: ["alto", "medio", "bajo"],
    },
  },
} as const
