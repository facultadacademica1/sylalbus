/**
 * Normalizes text by converting to uppercase and removing accents and special characters
 * @param text - The text to normalize
 * @returns Normalized text in uppercase without accents or special characters
 */
export function normalizeText(text: string): string {
  return text
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '') // Remove accents
    .replace(/[^A-Z0-9\s]/gi, '') // Remove special characters, keep letters, numbers and spaces
    .toUpperCase()
    .trim();
}

/**
 * Normalizes code by converting to uppercase and removing accents and special characters
 * More restrictive than normalizeText - only allows letters and numbers
 * @param code - The code to normalize
 * @returns Normalized code in uppercase without accents, special characters or spaces
 */
export function normalizeCode(code: string): string {
  return code
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '') // Remove accents
    .replace(/[^A-Z0-9]/gi, '') // Remove special characters and spaces, keep only letters and numbers
    .toUpperCase();
}