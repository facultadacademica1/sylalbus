import { useState } from "react";
import { User, Session } from "@supabase/supabase-js";
import { useAuth } from "@/hooks/useAuth";
import { AuthPage } from "@/components/auth/AuthPage";
import SyllabusManagement from "./SyllabusManagement";

const Index = () => {
  const { user, session, loading } = useAuth();
  const [authUser, setAuthUser] = useState<User | null>(null);
  const [authSession, setAuthSession] = useState<Session | null>(null);

  const handleAuthSuccess = (user: User, session: Session) => {
    setAuthUser(user);
    setAuthSession(session);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-lg">Cargando...</div>
      </div>
    );
  }

  if (!user && !authUser) {
    return <AuthPage onAuthSuccess={handleAuthSuccess} />;
  }

  return <SyllabusManagement user={user || authUser} session={session || authSession} />;
};

export default Index;
