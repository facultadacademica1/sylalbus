import { useState } from "react";
import { User, Session } from "@supabase/supabase-js";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, BookOpen, Users, GraduationCap, FileText, LogOut } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { SyllabusForm } from "@/components/syllabus/SyllabusForm";
import { SyllabusList } from "@/components/syllabus/SyllabusList";
import { AdminPanel } from "@/components/syllabus/AdminPanel";
import { SubjectLearningOutcomes } from "@/components/syllabus/SubjectLearningOutcomes";
import { CompetenciesManagement } from "@/components/syllabus/CompetenciesManagement";

interface SyllabusManagementProps {
  user: User | null;
  session: Session | null;
}

const SyllabusManagement = ({ user, session }: SyllabusManagementProps) => {
  const { signOut } = useAuth();
  const [activeTab, setActiveTab] = useState("list");
  const [showForm, setShowForm] = useState(false);
  const [editingSyllabus, setEditingSyllabus] = useState<any>(null);
  const [viewingSyllabus, setViewingSyllabus] = useState<any>(null);

  const handleSignOut = async () => {
    await signOut();
  };

  const handleEditSyllabus = (syllabus: any) => {
    setEditingSyllabus(syllabus);
    setShowForm(true);
  };

  const handleViewSyllabus = (syllabus: any) => {
    setViewingSyllabus(syllabus);
  };

  const handleCloseForm = () => {
    setShowForm(false);
    setEditingSyllabus(null);
  };

  const handleCloseView = () => {
    setViewingSyllabus(null);
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto py-8">
        <div className="mb-8 flex justify-between items-center">
          <div>
            <h1 className="text-4xl font-bold mb-2">Sistema de Gestión de Syllabus</h1>
            <p className="text-xl text-muted-foreground">
              Universidad Espíritu Santo - Recopilación de información académica
            </p>
            <p className="text-sm text-muted-foreground mt-1">
              Bienvenido: {user?.email}
            </p>
          </div>
          <Button variant="outline" onClick={handleSignOut} className="flex items-center gap-2">
            <LogOut className="h-4 w-4" />
            Cerrar Sesión
          </Button>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="list" className="flex items-center gap-2">
              <FileText className="h-4 w-4" />
              Syllabus
            </TabsTrigger>
            <TabsTrigger value="subjects" className="flex items-center gap-2">
              <BookOpen className="h-4 w-4" />
              Asignaturas
            </TabsTrigger>
            <TabsTrigger value="competencies" className="flex items-center gap-2">
              <GraduationCap className="h-4 w-4" />
              Competencias
            </TabsTrigger>
            <TabsTrigger value="admin" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              Administración
            </TabsTrigger>
          </TabsList>

          <TabsContent value="list" className="space-y-6">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-2xl font-semibold">Gestión de Syllabus</h2>
                <p className="text-muted-foreground">
                  Crea y administra los syllabus de las asignaturas
                </p>
              </div>
              <Button onClick={() => setShowForm(true)} className="flex items-center gap-2">
                <Plus className="h-4 w-4" />
                Nuevo Syllabus
              </Button>
            </div>

            {showForm ? (
              <SyllabusForm 
                onClose={handleCloseForm} 
                editingSyllabus={editingSyllabus}
              />
            ) : viewingSyllabus ? (
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="text-xl font-semibold">Ver Syllabus</h3>
                  <Button variant="outline" onClick={handleCloseView}>
                    Volver a la lista
                  </Button>
                </div>
                <SyllabusForm 
                  viewOnly={true}
                  editingSyllabus={viewingSyllabus}
                  onClose={handleCloseView}
                />
              </div>
            ) : (
              <SyllabusList 
                onEdit={handleEditSyllabus}
                onView={handleViewSyllabus}
              />
            )}
          </TabsContent>

          <TabsContent value="subjects" className="space-y-6">
            <SubjectLearningOutcomes />
          </TabsContent>

          <TabsContent value="competencies" className="space-y-6">
            <CompetenciesManagement />
          </TabsContent>

          <TabsContent value="admin" className="space-y-6">
            <AdminPanel />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default SyllabusManagement;