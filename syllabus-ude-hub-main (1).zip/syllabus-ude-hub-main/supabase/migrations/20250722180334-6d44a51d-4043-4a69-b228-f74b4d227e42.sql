-- Create enum types for different levels and types
CREATE TYPE public.contribution_level AS ENUM ('alto', 'medio', 'bajo');
CREATE TYPE public.bibliography_type AS ENUM ('basica', 'complementaria');

-- Create faculties table
CREATE TABLE public.faculties (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    description TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create careers table
CREATE TABLE public.careers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    description TEXT,
    faculty_id UUID REFERENCES public.faculties(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create subjects table
CREATE TABLE public.subjects (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    code TEXT UNIQUE NOT NULL,
    career_id UUID REFERENCES public.careers(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create general competencies table (defined by faculty)
CREATE TABLE public.general_competencies (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    faculty_id UUID REFERENCES public.faculties(id) ON DELETE CASCADE,
    description TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create specific competencies table (defined by career)
CREATE TABLE public.specific_competencies (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    career_id UUID REFERENCES public.careers(id) ON DELETE CASCADE,
    description TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create syllabus table (main entity)
CREATE TABLE public.syllabus (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    subject_id UUID REFERENCES public.subjects(id) ON DELETE CASCADE,
    contribution_to_career TEXT NOT NULL,
    contact_hours INTEGER NOT NULL CHECK (contact_hours >= 0),
    practical_experimental_hours INTEGER NOT NULL CHECK (practical_experimental_hours >= 0),
    autonomous_learning_hours INTEGER NOT NULL CHECK (autonomous_learning_hours >= 0),
    created_by UUID REFERENCES auth.users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    UNIQUE(subject_id)
);

-- Create syllabus general competencies relationship table
CREATE TABLE public.syllabus_general_competencies (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    syllabus_id UUID REFERENCES public.syllabus(id) ON DELETE CASCADE,
    general_competency_id UUID REFERENCES public.general_competencies(id) ON DELETE CASCADE,
    contribution_level public.contribution_level NOT NULL,
    UNIQUE(syllabus_id, general_competency_id)
);

-- Create syllabus specific competencies relationship table
CREATE TABLE public.syllabus_specific_competencies (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    syllabus_id UUID REFERENCES public.syllabus(id) ON DELETE CASCADE,
    specific_competency_id UUID REFERENCES public.specific_competencies(id) ON DELETE CASCADE,
    contribution_level public.contribution_level NOT NULL,
    UNIQUE(syllabus_id, specific_competency_id)
);

-- Create learning outcomes table (RDA)
CREATE TABLE public.learning_outcomes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    syllabus_id UUID REFERENCES public.syllabus(id) ON DELETE CASCADE,
    description TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create bibliography table
CREATE TABLE public.bibliography (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    syllabus_id UUID REFERENCES public.syllabus(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    author TEXT NOT NULL,
    year INTEGER,
    publisher TEXT,
    type public.bibliography_type NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.faculties ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.careers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.subjects ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.general_competencies ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.specific_competencies ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.syllabus ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.syllabus_general_competencies ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.syllabus_specific_competencies ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.learning_outcomes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bibliography ENABLE ROW LEVEL SECURITY;

-- Create RLS policies (allowing authenticated users to read all data)
CREATE POLICY "Allow authenticated users to read faculties" ON public.faculties FOR SELECT TO authenticated USING (true);
CREATE POLICY "Allow authenticated users to read careers" ON public.careers FOR SELECT TO authenticated USING (true);
CREATE POLICY "Allow authenticated users to read subjects" ON public.subjects FOR SELECT TO authenticated USING (true);
CREATE POLICY "Allow authenticated users to read general competencies" ON public.general_competencies FOR SELECT TO authenticated USING (true);
CREATE POLICY "Allow authenticated users to read specific competencies" ON public.specific_competencies FOR SELECT TO authenticated USING (true);
CREATE POLICY "Allow authenticated users to read syllabus" ON public.syllabus FOR SELECT TO authenticated USING (true);
CREATE POLICY "Allow authenticated users to read syllabus general competencies" ON public.syllabus_general_competencies FOR SELECT TO authenticated USING (true);
CREATE POLICY "Allow authenticated users to read syllabus specific competencies" ON public.syllabus_specific_competencies FOR SELECT TO authenticated USING (true);
CREATE POLICY "Allow authenticated users to read learning outcomes" ON public.learning_outcomes FOR SELECT TO authenticated USING (true);
CREATE POLICY "Allow authenticated users to read bibliography" ON public.bibliography FOR SELECT TO authenticated USING (true);

-- Create policies for authenticated users to manage syllabus data
CREATE POLICY "Allow authenticated users to insert syllabus" ON public.syllabus FOR INSERT TO authenticated WITH CHECK (auth.uid() = created_by);
CREATE POLICY "Allow authenticated users to update their syllabus" ON public.syllabus FOR UPDATE TO authenticated USING (auth.uid() = created_by);
CREATE POLICY "Allow authenticated users to delete their syllabus" ON public.syllabus FOR DELETE TO authenticated USING (auth.uid() = created_by);

-- Allow authenticated users to manage related syllabus data
CREATE POLICY "Allow authenticated users to manage syllabus general competencies" ON public.syllabus_general_competencies FOR ALL TO authenticated USING (true);
CREATE POLICY "Allow authenticated users to manage syllabus specific competencies" ON public.syllabus_specific_competencies FOR ALL TO authenticated USING (true);
CREATE POLICY "Allow authenticated users to manage learning outcomes" ON public.learning_outcomes FOR ALL TO authenticated USING (true);
CREATE POLICY "Allow authenticated users to manage bibliography" ON public.bibliography FOR ALL TO authenticated USING (true);

-- Create function to update timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create triggers for automatic timestamp updates
CREATE TRIGGER update_faculties_updated_at BEFORE UPDATE ON public.faculties FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_careers_updated_at BEFORE UPDATE ON public.careers FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_subjects_updated_at BEFORE UPDATE ON public.subjects FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_general_competencies_updated_at BEFORE UPDATE ON public.general_competencies FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_specific_competencies_updated_at BEFORE UPDATE ON public.specific_competencies FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_syllabus_updated_at BEFORE UPDATE ON public.syllabus FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_learning_outcomes_updated_at BEFORE UPDATE ON public.learning_outcomes FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_bibliography_updated_at BEFORE UPDATE ON public.bibliography FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();