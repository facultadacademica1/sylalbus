-- Add INSERT, UPDATE, DELETE policies for admin tables

-- Policies for faculties table
CREATE POLICY "Allow authenticated users to insert faculties" 
ON public.faculties 
FOR INSERT 
WITH CHECK (true);

CREATE POLICY "Allow authenticated users to update faculties" 
ON public.faculties 
FOR UPDATE 
USING (true);

CREATE POLICY "Allow authenticated users to delete faculties" 
ON public.faculties 
FOR DELETE 
USING (true);

-- Policies for careers table
CREATE POLICY "Allow authenticated users to insert careers" 
ON public.careers 
FOR INSERT 
WITH CHECK (true);

CREATE POLICY "Allow authenticated users to update careers" 
ON public.careers 
FOR UPDATE 
USING (true);

CREATE POLICY "Allow authenticated users to delete careers" 
ON public.careers 
FOR DELETE 
USING (true);

-- Policies for subjects table
CREATE POLICY "Allow authenticated users to insert subjects" 
ON public.subjects 
FOR INSERT 
WITH CHECK (true);

CREATE POLICY "Allow authenticated users to update subjects" 
ON public.subjects 
FOR UPDATE 
USING (true);

CREATE POLICY "Allow authenticated users to delete subjects" 
ON public.subjects 
FOR DELETE 
USING (true);

-- Policies for general_competencies table
CREATE POLICY "Allow authenticated users to insert general competencies" 
ON public.general_competencies 
FOR INSERT 
WITH CHECK (true);

CREATE POLICY "Allow authenticated users to update general competencies" 
ON public.general_competencies 
FOR UPDATE 
USING (true);

CREATE POLICY "Allow authenticated users to delete general competencies" 
ON public.general_competencies 
FOR DELETE 
USING (true);

-- Policies for specific_competencies table
CREATE POLICY "Allow authenticated users to insert specific competencies" 
ON public.specific_competencies 
FOR INSERT 
WITH CHECK (true);

CREATE POLICY "Allow authenticated users to update specific competencies" 
ON public.specific_competencies 
FOR UPDATE 
USING (true);

CREATE POLICY "Allow authenticated users to delete specific competencies" 
ON public.specific_competencies 
FOR DELETE 
USING (true);