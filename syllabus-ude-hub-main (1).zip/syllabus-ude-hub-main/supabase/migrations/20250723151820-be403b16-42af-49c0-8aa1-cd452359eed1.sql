-- Disable Row Level Security on admin tables for public access

ALTER TABLE public.faculties DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.careers DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.subjects DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.general_competencies DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.specific_competencies DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.syllabus DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.syllabus_general_competencies DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.syllabus_specific_competencies DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.learning_outcomes DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.bibliography DISABLE ROW LEVEL SECURITY;