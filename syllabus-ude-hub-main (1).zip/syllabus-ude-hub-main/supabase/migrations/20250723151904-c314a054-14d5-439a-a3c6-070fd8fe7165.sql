-- Clean up orphaned RLS policies since we disabled RLS

-- Drop all policies from faculties table
DROP POLICY IF EXISTS "Allow authenticated users to read faculties" ON public.faculties;
DROP POLICY IF EXISTS "Allow authenticated users to insert faculties" ON public.faculties;
DROP POLICY IF EXISTS "Allow authenticated users to update faculties" ON public.faculties;
DROP POLICY IF EXISTS "Allow authenticated users to delete faculties" ON public.faculties;

-- Drop all policies from careers table
DROP POLICY IF EXISTS "Allow authenticated users to read careers" ON public.careers;
DROP POLICY IF EXISTS "Allow authenticated users to insert careers" ON public.careers;
DROP POLICY IF EXISTS "Allow authenticated users to update careers" ON public.careers;
DROP POLICY IF EXISTS "Allow authenticated users to delete careers" ON public.careers;

-- Drop all policies from subjects table
DROP POLICY IF EXISTS "Allow authenticated users to read subjects" ON public.subjects;
DROP POLICY IF EXISTS "Allow authenticated users to insert subjects" ON public.subjects;
DROP POLICY IF EXISTS "Allow authenticated users to update subjects" ON public.subjects;
DROP POLICY IF EXISTS "Allow authenticated users to delete subjects" ON public.subjects;

-- Drop all policies from general_competencies table
DROP POLICY IF EXISTS "Allow authenticated users to read general competencies" ON public.general_competencies;
DROP POLICY IF EXISTS "Allow authenticated users to insert general competencies" ON public.general_competencies;
DROP POLICY IF EXISTS "Allow authenticated users to update general competencies" ON public.general_competencies;
DROP POLICY IF EXISTS "Allow authenticated users to delete general competencies" ON public.general_competencies;

-- Drop all policies from specific_competencies table
DROP POLICY IF EXISTS "Allow authenticated users to read specific competencies" ON public.specific_competencies;
DROP POLICY IF EXISTS "Allow authenticated users to insert specific competencies" ON public.specific_competencies;
DROP POLICY IF EXISTS "Allow authenticated users to update specific competencies" ON public.specific_competencies;
DROP POLICY IF EXISTS "Allow authenticated users to delete specific competencies" ON public.specific_competencies;

-- Drop all policies from syllabus table
DROP POLICY IF EXISTS "Allow authenticated users to read syllabus" ON public.syllabus;
DROP POLICY IF EXISTS "Allow authenticated users to insert syllabus" ON public.syllabus;
DROP POLICY IF EXISTS "Allow authenticated users to update their syllabus" ON public.syllabus;
DROP POLICY IF EXISTS "Allow authenticated users to delete their syllabus" ON public.syllabus;

-- Drop all policies from syllabus_general_competencies table
DROP POLICY IF EXISTS "Allow authenticated users to read syllabus general competencies" ON public.syllabus_general_competencies;
DROP POLICY IF EXISTS "Allow authenticated users to manage syllabus general competenci" ON public.syllabus_general_competencies;

-- Drop all policies from syllabus_specific_competencies table
DROP POLICY IF EXISTS "Allow authenticated users to read syllabus specific competencie" ON public.syllabus_specific_competencies;
DROP POLICY IF EXISTS "Allow authenticated users to manage syllabus specific competenc" ON public.syllabus_specific_competencies;

-- Drop all policies from learning_outcomes table
DROP POLICY IF EXISTS "Allow authenticated users to read learning outcomes" ON public.learning_outcomes;
DROP POLICY IF EXISTS "Allow authenticated users to manage learning outcomes" ON public.learning_outcomes;

-- Drop all policies from bibliography table
DROP POLICY IF EXISTS "Allow authenticated users to read bibliography" ON public.bibliography;
DROP POLICY IF EXISTS "Allow authenticated users to manage bibliography" ON public.bibliography;