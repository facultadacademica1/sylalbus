-- Eliminar el constraint único de subject_id en syllabus para permitir múltiples syllabus por asignatura
ALTER TABLE public.syllabus DROP CONSTRAINT IF EXISTS syllabus_subject_id_key;

-- Agregar subject_id a learning_outcomes si no existe
DO $$ 
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='learning_outcomes' AND column_name='subject_id') THEN
        ALTER TABLE public.learning_outcomes ADD COLUMN subject_id UUID;
    END IF;
END $$;

-- Quitar career_id de learning_outcomes ya que ahora van a nivel de asignatura
ALTER TABLE public.learning_outcomes DROP COLUMN IF EXISTS career_id;