-- Habilitar RLS en todas las tablas que no lo tienen
ALTER TABLE public.bibliography ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.careers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.faculties ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.general_competencies ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.learning_outcomes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.specific_competencies ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.subjects ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.syllabus ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.syllabus_general_competencies ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.syllabus_specific_competencies ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.subject_learning_outcomes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.syllabus_learning_outcomes ENABLE ROW LEVEL SECURITY;