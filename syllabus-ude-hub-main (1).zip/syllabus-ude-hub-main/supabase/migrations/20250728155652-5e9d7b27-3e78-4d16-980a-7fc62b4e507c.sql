-- Crear políticas para subject_learning_outcomes
CREATE POLICY "Allow authenticated users to manage subject learning outcomes" 
ON public.subject_learning_outcomes 
FOR ALL 
USING (true);

-- Crear políticas para syllabus_learning_outcomes  
CREATE POLICY "Allow authenticated users to manage syllabus learning outcomes" 
ON public.syllabus_learning_outcomes 
FOR ALL 
USING (true);