-- Create a junction table for competencias específicas transversales (many-to-many relationship)
CREATE TABLE public.career_specific_competencies (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  career_id UUID NOT NULL,
  specific_competency_id UUID NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(career_id, specific_competency_id)
);

-- Enable RLS
ALTER TABLE public.career_specific_competencies ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Allow authenticated users to manage career specific competencies"
ON public.career_specific_competencies
FOR ALL
TO authenticated
USING (true);

-- Modify specific_competencies table to remove the direct career_id relationship
-- Since we're making them transversal, we'll make career_id nullable
ALTER TABLE public.specific_competencies ALTER COLUMN career_id DROP NOT NULL;