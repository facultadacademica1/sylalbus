-- Add code column to learning_outcomes table
ALTER TABLE public.learning_outcomes 
ADD COLUMN code TEXT;

-- Create function to generate learning outcome codes
CREATE OR REPLACE FUNCTION public.generate_learning_outcome_code()
RETURNS TRIGGER AS $$
DECLARE
    subject_code TEXT;
    counter INTEGER;
    new_code TEXT;
BEGIN
    -- Get subject code
    SELECT s.code INTO subject_code
    FROM subjects s 
    WHERE s.id = NEW.subject_id;
    
    -- If no subject, use 'LO' as prefix
    IF subject_code IS NULL THEN
        subject_code := 'LO';
    END IF;
    
    -- Get next counter for this subject
    SELECT COALESCE(MAX(CAST(RIGHT(code, 3) AS INTEGER)), 0) + 1 INTO counter
    FROM learning_outcomes 
    WHERE code LIKE subject_code || 'LO%';
    
    -- Generate new code format: [SUBJECT_CODE]LO[001]
    new_code := subject_code || 'LO' || LPAD(counter::TEXT, 3, '0');
    
    NEW.code := new_code;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for learning outcomes code generation
CREATE TRIGGER generate_learning_outcome_code_trigger
    BEFORE INSERT ON public.learning_outcomes
    FOR EACH ROW
    EXECUTE FUNCTION public.generate_learning_outcome_code();