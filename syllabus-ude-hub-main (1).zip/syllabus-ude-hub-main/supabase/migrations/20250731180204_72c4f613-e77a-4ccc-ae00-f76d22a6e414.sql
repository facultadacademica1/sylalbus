-- Add name column to specific_competencies table
ALTER TABLE public.specific_competencies 
ADD COLUMN name TEXT;