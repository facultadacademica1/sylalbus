-- Add modalidad field to syllabus table
ALTER TABLE public.syllabus 
ADD COLUMN modalidad TEXT CHECK (modalidad IN ('online', 'presencial')) DEFAULT 'presencial';