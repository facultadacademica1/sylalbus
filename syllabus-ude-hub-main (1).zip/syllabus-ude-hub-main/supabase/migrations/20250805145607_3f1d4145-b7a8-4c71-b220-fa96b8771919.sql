-- Crear tabla para asociar asignaturas con competencias generales
CREATE TABLE public.subject_general_competencies (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  subject_id UUID NOT NULL,
  general_competency_id UUID NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(subject_id, general_competency_id)
);

-- Habilitar RLS en la nueva tabla
ALTER TABLE public.subject_general_competencies ENABLE ROW LEVEL SECURITY;

-- Crear políticas RLS
CREATE POLICY "Allow authenticated users to manage subject general competencies" 
ON public.subject_general_competencies 
FOR ALL 
USING (true);

-- Agregar índices para mejor rendimiento
CREATE INDEX idx_subject_general_competencies_subject_id ON public.subject_general_competencies(subject_id);
CREATE INDEX idx_subject_general_competencies_general_competency_id ON public.subject_general_competencies(general_competency_id);