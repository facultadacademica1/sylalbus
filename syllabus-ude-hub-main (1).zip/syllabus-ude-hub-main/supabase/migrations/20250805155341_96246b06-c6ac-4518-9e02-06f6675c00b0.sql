-- Add foreign keys to enable automatic joins in Supabase

-- Add foreign key to subject_general_competencies table
ALTER TABLE subject_general_competencies 
ADD CONSTRAINT fk_subject_general_competencies_subject 
FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE;

ALTER TABLE subject_general_competencies 
ADD CONSTRAINT fk_subject_general_competencies_general_competency 
FOREIGN KEY (general_competency_id) REFERENCES general_competencies(id) ON DELETE CASCADE;

-- Add foreign key to career_specific_competencies table  
ALTER TABLE career_specific_competencies 
ADD CONSTRAINT fk_career_specific_competencies_career 
FOREIGN KEY (career_id) REFERENCES careers(id) ON DELETE CASCADE;

ALTER TABLE career_specific_competencies 
ADD CONSTRAINT fk_career_specific_competencies_specific_competency 
FOREIGN KEY (specific_competency_id) REFERENCES specific_competencies(id) ON DELETE CASCADE;